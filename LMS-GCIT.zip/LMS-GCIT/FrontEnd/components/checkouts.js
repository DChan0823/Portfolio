"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import {CheckOutList} from '../components/CheckOutList';

export class CheckOuts extends React.Component{

    render() {
        
            return(
                <div>
                    <CheckOutList checkOutList = {this.props.checkOutList} />
                </div>
            );
        
    }
}

CheckOuts.propTypes = {
    checkOutList: PropTypes.array.isRequired
};