"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import ReturnActions from '../actions/returnActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class ReturnList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          card: -1,
          branch: -1,
          book: -1,
          copies:""
        };
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleCardChange = this.handleCardChange.bind(this);
        this.handleCopiesChange = this.handleCopiesChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleNew = this.handleNew.bind(this);
        this.handleReturn = this.handleReturn.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleCardChange(event) {
        this.setState({card: event.target.value});
    }

    handleCopiesChange(event) {
        this.setState({copies: event.target.value});
    }

    handleSubmit(event) {
        ReturnActions.readBorrLoans(this.state.card);
        event.preventDefault();
    }

    handleUpdateSubmit(event) {
        ReturnActions.removeLoan(this.state.book, this.state.branch, this.state.card);
        event.preventDefault();
        this.closeModal();
    }

    handleNew(){
        this.setState({isUpdate: -1});
        this.openModal();
    }

    handleReturn(bk, br, card) {
        this.setState({book: bk, branch: br, card: card});
        this.openModal();
    }

    createReturnRow(loan){
        return (
            <tr key={[loan.bklnId.bookId, loan.bklnId.branchId, loan.bklnId.cardNo]}>
                <td>{loan.bklnId.bookId}</td>
                <td>{loan.bklnId.branchId}</td>
                <td>{loan.bklnId.cardNo}</td>
                <td> {loan.dateOut} </td>
                <td> {loan.dueDate} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleReturn(loan.bklnId.bookId, loan.bklnId.branchId, loan.bklnId.cardNo)} >Return</button></td>
            </tr>
        );
    }

    /*UNSAFE_componentWillMount(){
        ReturnActions.readBorrLoans(this.state.card);
    }*/

    _componentDidMount(){
        ReturnActions.readBorrLoans(this.state.card);
    }
    
    render() {
        return(
            <div>
                <form onSubmit={this.handleSubmit}>
                  <label>
                     CardNo:
                    <input type="text" card={this.state.card} onChange={this.handleCardChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>

                <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Return Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please Confirm Return</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <input type="submit" value="Yes" />
                </form>
                </Modal>

                <h1>Loans</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>BookId</th>
                            <th>BranchId</th>
                            <th>CardNo</th>
                            <th>DateOut</th>
                            <th>DueDate</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.returnList.map(this.createReturnRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

ReturnList.propTypes = {
    returnList: PropTypes.array.isRequired
};