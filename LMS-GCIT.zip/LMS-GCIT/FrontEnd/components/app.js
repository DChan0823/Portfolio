"use strict"

import React from 'react';
import {Switch, Route} from 'react-router-dom';

import {Header} from './header.js';
import {Home} from './home.js';
import {Books} from './books.js';
import {Admin} from './admin.js';
import {Librarian} from './librarian.js'
import {Publishers} from './publishers.js';
import {Authors} from './authors.js';
import {Borrowers} from './borrowers.js';
import {Branches} from './branches.js';
import {BranchesLib} from './brancheslib.js';
//import {BranchCopies} from './branchcopies.js';
import {Copies} from './copies.js';
//import {CopiesHome} from './copiesHome.js';
import {Loans} from './loans.js';
import {BorrowerHome} from './borrowerHome';
import {CheckOuts} from './checkouts.js';
import {Returns} from './returns.js';
import BookStore from '../stores/bookStore';
import PublisherStore from '../stores/publisherStore';
import AuthorStore from '../stores/authorStore';
import BorrowerStore from '../stores/borrowerStore';
import BranchStore from '../stores/branchStore';
import LoansStore from '../stores/loansStore';
import CopiesStore from '../stores/copiesStore';
import LendingStore from '../stores/lendingStore';
import ReturnStore from '../stores/returnStore';

export class App extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            bookList:[],
            publisherList:[],
            authorList:[],
            borrowerList: [],
            branchList: [],
            loanList: [],
            copiesList: [],
            checkoutList: [],
            returnList: []
        };
    }
//<Route exact path='/borrower/checkout' render={(props) => (<CheckOuts {...props} checkoutList={this.state.checkoutList} />)}/>
//LendingStore.addChangeListener(this._onLendingChange.bind(this));
//LendingStore.removeChangeListener(this._onLendingChange.bind(this));
/*
_onLendingChang(){
        this.setState({checkoutList: LendingStore.getAllLoans()});
    }
 */
//<Route exact path='/librarian/copies' component={CopiesHome}/>
//<Route exact path='/librarian/copies' render={(props) => (<BranchCopies {...props} branchList={this.state.branchList} />)}/>
    render() {
        return(
            <div>
                <Header />
                <Switch>
                    <Route exact path='/' component={Home}/>
                    <Route exact path='/admin' component={Admin}/>
                    <Route exact path='/librarian' component={Librarian}/>
                    <Route exact path='/borrower' component={BorrowerHome}/>
                    <Route exact path='/admin/books' render={(props) => (<Books {...props} bookList={this.state.bookList} />)}/>
                    <Route exact path='/admin/publishers' render={(props) => (<Publishers {...props} publisherList={this.state.publisherList} />)}/>
                    <Route exact path='/admin/authors' render={(props) => (<Authors {...props} authorList={this.state.authorList} />)}/>
                    <Route exact path='/admin/borrowers' render={(props) => (<Borrowers {...props} borrowerList={this.state.borrowerList} />)}/>
                    <Route exact path='/admin/branches' render={(props) => (<Branches {...props} branchList={this.state.branchList} />)}/>
                    <Route exact path='/admin/loans' render={(props) => (<Loans {...props} loanList={this.state.loanList} />)}/>
                    <Route exact path='/librarian/branches' render={(props) => (<BranchesLib {...props} branchList={this.state.branchList} />)}/>
                    <Route exact path='/librarian/copies' render={(props) => (<Copies {...props} copiesList={this.state.copiesList} />)}/>
                    <Route exact path='/borrower/checkOut' render={(props) => (<CheckOuts {...props} checkoutList={this.state.checkoutList} />)}/>
                    <Route exact path='/borrower/return' render={(props) => (<Returns {...props} returnList={this.state.returnList} />)}/>
                </Switch>
            </div>
        );
    }

    UNSAFE_componentWillMount(){
        BookStore.addChangeListener(this._onBookChange.bind(this));
        PublisherStore.addChangeListener(this._onPublisherChange.bind(this));
        AuthorStore.addChangeListener(this._onAuthorChange.bind(this));
        BorrowerStore.addChangeListener(this._onBorrowerChange.bind(this));
        BranchStore.addChangeListener(this._onBranchChange.bind(this));
        LoansStore.addChangeListener(this._onLoanChange.bind(this));
        CopiesStore.addChangeListener(this._onCopiesChange.bind(this));
        LendingStore.addChangeListener(this._onLendingChange.bind(this));
        ReturnStore.addChangeListener(this._onReturnChange.bind(this));
    }

    UNSAFE_componentWillUnmount(){
        BookStore.removeChangeListener(this._onBookChange.bind(this));
        PublisherStore.removeChangeListener(this._onPublisherChange.bind(this));
        AuthorStore.removeChangeListener(this._onAuthorChange.bind(this));
        BorrowerStore.removeChangeListener(this._onBorrowerChange.bind(this));
        BranchStore.removeChangeListener(this._onBranchChange.bind(this));
        LoansStore.removeChangeListener(this._onLoanChange.bind(this));
        CopiesStore.removeChangeListener(this._onCopiesChange.bind(this));
        LendingStore.removeChangeListener(this._onLendingChange.bind(this));
        ReturnStore.removeChangeListener(this._onReturnChange.bind(this));
    }

    _onBookChange(){
        this.setState({bookList: BookStore.getAllBooks()});
    }

    _onPublisherChange(){
        this.setState({publisherList: PublisherStore.getAllPublishers()});
    }

    _onAuthorChange(){
        this.setState({authorList: AuthorStore.getAllAuthors()});
    }

    _onBorrowerChange(){
        this.setState({borrowerList: BorrowerStore.getAllBorrowers()});
    }

    _onBranchChange(){
        this.setState({branchList: BranchStore.getAllBranches()});
    }

    _onLoanChange(){
        this.setState({loanList: LoansStore.getAllLoans()});
    }

    _onCopiesChange(){
        this.setState({copiesList: CopiesStore.getAllCopies()});
    }

    _onLendingChange(){
        this.setState({checkoutList: LendingStore.getAllLendings()});
    }

    _onReturnChange(){
        this.setState({returnList: ReturnStore.getAllReturns()});
    }
}