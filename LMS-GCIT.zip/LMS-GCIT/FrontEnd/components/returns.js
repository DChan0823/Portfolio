"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import {ReturnList} from '../components/ReturnList';

export class Returns extends React.Component{

    render() {
        
            return(
                <div>
                    <ReturnList returnList = {this.props.returnList} />
                </div>
            );
        
    }
}

Returns.propTypes = {
    returnList: PropTypes.array.isRequired
};