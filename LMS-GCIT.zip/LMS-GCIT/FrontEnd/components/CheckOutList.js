"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import LendingActions from '../actions/lendingActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class CheckOutList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          branchChosen: -1,
          cardNo: -1,
          branchId: -1,
          bookId: -1,
          dateOut: "",
          dueDate: ""
        };
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleBranchChange = this.handleBranchChange.bind(this);
        this.handleCardChange = this.handleCardChange.bind(this);
        this.handleBookChange = this.handleBookChange.bind(this);
        this.handleOutChange = this.handleOutChange.bind(this);
        this.handleDueChange = this.handleDueChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleNew = this.handleNew.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleBranchChange(event) {
        this.setState({branchId: event.target.value});
    }

    handleCardChange(event) {
        this.setState({cardNo: event.target.value});
    }

    handleBookChange(event) {
        this.setState({bookId: event.target.value});
    }

    handleOutChange(event) {
        this.setState({dateOut: event.target.value});
    }

    handleDueChange(event) {
        this.setState({dueDate: event.target.value});
    }
/*
alert('Book Checked Out!'+' CardNo:'+this.state.cardNo+' BranchId: '+this.state.branchId+' BookId: '+this.state.bookId + ' DateOut:'+input.dateOut+'DueDate:'+input.dueDate);
LendingActions.newLoan(this.state.cardNo, this.state.branchId, this.state.bookId, input);
        event.preventDefault();
*/
    handleSubmit() {
        this.openModal();
    }

    handleUpdateSubmit(event) {
        var input = {
          "dateOut": this.state.dateOut,
          "dueDate": this.state.dueDate
        };
        LendingActions.newLoan(this.state.cardNo, this.state.branchId, this.state.bookId, input);
        alert('Book Checked Out!'+' CardNo:'+this.state.cardNo+' BranchId: '+this.state.branchId+' BookId: '+this.state.bookId + ' DateOut:'+input.dateOut+'DueDate:'+input.dueDate);
        event.preventDefault();
    }

    handleNew(){
        this.setState({isUpdate: -1});
        this.openModal();
    }

    handleUpdate(bkid) {
        this.setState({bookId: bkid});
        this.openModal();
    }

    handleBranch(id) {
        this.setState({branchId: id});
        this.setState({branchChosen: 1});
    }

    createLoansRow(loan){
        return (
            <tr key={[loan.bklnId.bookId, loan.bklnId.branchId, loan.bklnId.cardNo]}>
                <td>{loan.bklnId.cardNo}</td>
                <td>{loan.bklnId.branchId}</td>
                <td>{loan.bklnId.bookId}</td>
                <td> {loan.dateOut} </td>
                <td> {loan.dueDate} </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        LendingActions.readTheLoan(this.state.cardNo, this.state.branchId, this.state.bookId);
    }
    
    render() {
        return(
            <div>
                <form onSubmit={this.handleSubmit}>
                  <label>
                     CardNo:
                    <input type="text" cardNo={this.state.cardNo} onChange={this.handleCardChange} />
                  </label>
                  <label>
                     BranchId:
                    <input type="text" branchId={this.state.branchId} onChange={this.handleBranchChange} />
                  </label>
                  <label>
                     BookId:
                    <input type="text" bookId={this.state.bookId} onChange={this.handleBookChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>

                <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter Number of Copies values</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                <label>
                     DateOut:
                    <input type="text" dateOut={this.state.dateOut} onChange={this.handleOutChange} />
                  </label>
                  <label>
                     DueDate:
                    <input type="text" dueDate={this.state.dueDate} onChange={this.handleDueChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>

            </div>
        );
    }
}

CheckOutList.propTypes = {
    checkoutList: PropTypes.array.isRequired
};