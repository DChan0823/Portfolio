"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import {LoanList} from '../components/LoanList';

export class Loans extends React.Component{

    render() {
        return(
            <div>
                <LoanList loanList = {this.props.loanList} />
            </div>
        );
    }
}

Loans.propTypes = {
    loanList: PropTypes.array.isRequired
};