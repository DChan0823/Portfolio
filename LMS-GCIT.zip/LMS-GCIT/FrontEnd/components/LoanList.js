"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import LoansActions from '../actions/loansActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class LoanList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          book: "",
          branch: "",
          card: "",
          dateout: "",
          duedate: ""};
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleBookChange = this.handleBookChange.bind(this);
        this.handleBranchChange = this.handleBranchChange.bind(this);
        this.handleCardChange = this.handleCardChange.bind(this);
        this.handleOutChange = this.handleOutChange.bind(this);
        this.handleDueChange = this.handleDueChange.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#f00';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleBookChange(event) {
        this.setState({book: event.target.value});
    }
  
    handleBranchChange(event) {
        this.setState({branch: event.target.value});
    }
  
    handleCardChange(event) {
        this.setState({card: event.target.value});
    }

    handleOutChange(event) {
        this.setState({dateout: event.target.value});
    }

    handleDueChange(event) {
        this.setState({duedate: event.target.value});
    }

    handleUpdateSubmit(event) {
        var input = {
            "dateOut":this.state.dateout,
            "dueDate":this.state.duedate
        };
        LoansActions.updateLoan(this.state.book, this.state.branch, this.state.card, input);
        alert('Loan Date Updated!');
        event.preventDefault();
        this.closeModal();
    }

    handleUpdate(bk, br, cd, out) {
        this.setState({book: bk, branch: br, card: cd, dateout: out});
        alert('Book Returned!'+' BookId:'+this.state.book+' BranchId:'+this.state.branch+'CardNo:'+this.state.card);
        this.openModal();
    }

    createLoansRow(loan){
        return (
            <tr key={[loan.bklnId.bookId, loan.bklnId.branchId, loan.bklnId.cardNo]}>
                <td>{loan.bklnId.bookId}</td>
                <td>{loan.bklnId.branchId}</td>
                <td>{loan.bklnId.cardNo}</td>
                <td> {loan.dateOut} </td>
                <td> {loan.dueDate} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleUpdate(loan.bklnId.bookId, loan.bklnId.branchId, loan.bklnId.cardNo, loan.dateOut)} >Update</button></td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        LoansActions.readLoans();
    }

    render() {
        return(
            <div>
              <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for Due Date Update</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <label>
                    DueDate:
                    <input type="text" duedate={this.state.duedate} onChange={this.handleDueChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>

                <h1>Book Loans</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>BookId</th>
                            <th>BranchId</th>
                            <th>CardNo</th>
                            <th>DateOut</th>
                            <th>DueDate</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.loanList.map(this.createLoansRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

LoanList.propTypes = {
    loanList: PropTypes.array.isRequired
};