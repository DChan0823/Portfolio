"use strict"

import React from 'react';
import {Link} from 'react-router-dom';

export class Admin extends React.Component{

    render() {
        return(
            <div>
                <table className="table">
                    <thead>
                        <tr>
                            <th>Administrator Functions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <li><Link to="/admin/authors" replace>Authors</Link></li>
                        <li><Link to="/admin/books" replace>Books</Link></li>
                        <li><Link to="/admin/loans" replace>Book Loans</Link></li>
                        <li><Link to="/admin/borrowers" replace>Borrowers</Link></li>
                        <li><Link to="/admin/branches" replace>Library Branches</Link></li>
                        <li><Link to="/admin/publishers" replace>Publishers</Link></li>
                    </tbody>    
                </table>
            </div>
        );
    }
}