"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import BranchActions from '../actions/branchActions';

export class BranchListCopies extends React.Component{

    constructor(props){
        super(props);
        this.state={
          branchName: "",
          branchAddress: ""
        };
        this.handleClick=this.handleClick.bind(this);
    }

    handleClick(id){
        this.setState({branchChosen: id});

    }

    createBranchRow(branch){
        return (
            <tr key={branch.branchId}>
                <td> {branch.branchId} </td>
                <td> {branch.branchName} </td>
                <td> {branch.branchAddress} </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        BranchActions.readBranches();
    }

    render() {
            return(
                <div>
                    <h1>Choose Your Branch</h1>
                    
                    <table className="table">
                        <thead>
                            <tr>
                                <th>BranchId</th>
                                <th>Branch Name</th>
                                <th>Branch Address</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.branchList.map(this.createBranchRow, this)}
                        </tbody>
                    </table>
                </div>
            );
    }
}

BranchListCopies.propTypes = {
    branchList: PropTypes.array.isRequired
};