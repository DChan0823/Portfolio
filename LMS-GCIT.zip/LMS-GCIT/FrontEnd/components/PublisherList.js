"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import PublisherActions from '../actions/publisherActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class PublisherList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          isUpdate: -1,
          name: "",
          address: "",
          phone: ""};
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleAddressChange = this.handleAddressChange.bind(this);
        this.handlePhoneChange = this.handlePhoneChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleNew = this.handleNew.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleNameChange(event) {
        this.setState({name: event.target.value});
    }
  
    handleAddressChange(event) {
        this.setState({address: event.target.value});
    }
  
    handlePhoneChange(event) {
        this.setState({phone: event.target.value});
    }

    handleSubmit(event) {
        var input = {
          "publisherName":this.state.name,
          "publisherAddress":this.state.address,
          "publisherPhone":this.state.phone
        };
        PublisherActions.newPublisher(input);
        alert('Publisher added: ' + this.state.name);
        event.preventDefault();
        this.closeModal();
    }

    handleUpdateSubmit(event) {
        var input = {
          "publisherName":this.state.name,
          "publisherAddress":this.state.address,
          "publisherPhone":this.state.phone
        };
        PublisherActions.updatePublisher(this.state.isUpdate, input);
        alert('Publisher updated: ' + this.state.name);
        event.preventDefault();
        this.closeModal();
    }

    handleNew(){
        this.setState({isUpdate: -1});
        this.openModal();
    }

    handleUpdate(id) {
        this.setState({isUpdate: id});
        this.openModal();
    }

    createPublisherRow(pub){
        return (
            <tr key={pub.publisherId}>
                <td> {pub.publisherId} </td>
                <td> {pub.publisherName} </td>
                <td> {pub.publisherAddress} </td>
                <td> {pub.publisherPhone} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleUpdate(pub.publisherId)} >Update</button>
                    <button className='btn btn-primary' onClick={() => PublisherActions.removePublisher(pub.publisherId)} >Delete</button> 
                </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        PublisherActions.readPublishers();
    }
    

    render() {
        return(
            <div>
              {this.state.isUpdate === -1 && <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Add Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for New Publisher</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleSubmit}>
                  <label>
                    Publisher Name:
                    <input type="text" name={this.state.name} onChange={this.handleNameChange} />
                  </label>
                  <label>
                    Publisher Address:
                    <input type="text" address={this.state.address} onChange={this.handleAddressChange} />
                  </label>
                  <label>
                    Publisher Phone:
                    <input type="text" phone={this.state.phone} onChange={this.handlePhoneChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>}
              
              {this.state.isUpdate != -1 && <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for Update Publisher</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <label>
                    Publisher Name:
                    <input type="text" name={this.state.name} onChange={this.handleNameChange} />
                  </label>
                  <label>
                    Publisher Address:
                    <input type="text" address={this.state.address} onChange={this.handleAddressChange} />
                  </label>
                  <label>
                    Publisher Phone:
                    <input type="text" phone={this.state.phone} onChange={this.handlePhoneChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>}

                <h1>Publishers</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>PublisherId</th>
                            <th>Publisher Name</th>
                            <th>Address</th>
                            <th>Phone</th>
                            <th><button
                            onClick = {this.handleNew}>Add</button></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.publisherList.map(this.createPublisherRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

PublisherList.propTypes = {
    publisherList: PropTypes.array.isRequired
};