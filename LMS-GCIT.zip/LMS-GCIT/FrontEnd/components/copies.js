"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import {CopiesList} from '../components/CopiesList';

export class Copies extends React.Component{

    render() {
        
            return(
                <div>
                    <CopiesList copiesList = {this.props.copiesList} />
                </div>
            );
        
    }
}

Copies.propTypes = {
    copiesList: PropTypes.array.isRequired
};