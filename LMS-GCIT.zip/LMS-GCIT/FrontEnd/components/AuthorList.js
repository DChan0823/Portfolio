"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import AuthorActions from '../actions/authorActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class AuthorList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          isUpdate: -1,
          name: ""};
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleNew = this.handleNew.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleNameChange(event) {
        this.setState({name: event.target.value});
    }

    handleSubmit(event) {
        var input = {
          "authorName":this.state.name
        };
        AuthorActions.newAuthor(input);
        alert('Author added: ' + this.state.name);
        event.preventDefault();
        this.closeModal();
    }

    handleUpdateSubmit(event) {
        var input = {
          "authorName":this.state.name
        };
        AuthorActions.updateAuthor(this.state.isUpdate, input);
        alert('Author updated: ' + this.state.name);
        event.preventDefault();
        this.closeModal();
    }

    handleNew(){
        this.setState({isUpdate: -1});
        this.openModal();
    }

    handleUpdate(id) {
        this.setState({isUpdate: id});
        this.openModal();
    }

    createAuthorRow(author){
        return (
            <tr key={author.authorId}>
                <td> {author.authorId} </td>
                <td> {author.authorName} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleUpdate(author.authorId)} >Update</button>
                    <button className='btn btn-primary' onClick={() => AuthorActions.removeAuthor(author.authorId)} >Delete</button> 
                </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        AuthorActions.readAuthors();
    }
    

    render() {
        return(
            <div>
              {this.state.isUpdate === -1 && <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Add Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for New Author</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleSubmit}>
                  <label>
                    Author Name:
                    <input type="text" name={this.state.name} onChange={this.handleNameChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>}
              
              {this.state.isUpdate != -1 && <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for Update Author</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <label>
                    Author Name:
                    <input type="text" name={this.state.name} onChange={this.handleNameChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>}

                <h1>Authors</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>AuthorId</th>
                            <th>Author Name</th>
                            <th><button
                            onClick = {this.handleNew}>Add</button></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.authorList.map(this.createAuthorRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

AuthorList.propTypes = {
    authorList: PropTypes.array.isRequired
};