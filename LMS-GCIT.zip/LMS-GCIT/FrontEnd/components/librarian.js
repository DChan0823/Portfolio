"use strict"

import React from 'react';
import {Link} from 'react-router-dom';

export class Librarian extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            branch: ""
        };
    }

    render() {
        return(
            <div>
                <table className="table">
                    <thead>
                        <tr>
                            <th>Librarian Functions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <li><Link to="/librarian/branches" replace>Edit Library Branch</Link></li>
                        <li><Link to="/librarian/copies" replace>Edit Book Copies</Link></li>
                    </tbody>    
                </table>
            </div>
        );
    }
}