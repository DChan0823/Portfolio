"use strict"

import React from 'react';
import {Link} from 'react-router-dom';
/*
<nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <Link to="/" className="navbar-brand">
                        <img width="90px" height="30px" src="images/logo.png" />
                    </Link>
                    <ul className="nav navbar-nav">
                        <li><Link to="/" replace>Home</Link></li>
                        <li><Link to="/books" replace>Books</Link></li>
                    </ul>
                </div>
            </nav>
            <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="dropdown-divider"></div>
                <span class="sr-only">(current)</span></a>
                <a class="nav-link">Home</a>

                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
*/
const myStyle =  {
    marginTop: "20px",
    marginRight : "30px"
}

export class Header extends React.Component{
    

    render() {
        return(
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
                <Link to="/" className="navbar-brand">
                    <img width="90px" height="30px" src="images/logo.png" />
                </Link>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        <li style={myStyle}><Link to="/" replace>Home</Link></li>
                        <li style={myStyle}><Link to="/admin" replace>Administrator</Link></li>
                        <li style={myStyle}><Link to="/librarian" replace>Librarian</Link></li>
                        <li style={myStyle}><Link to="/borrower" replace>Borrower</Link></li>
                    </ul>
                </div>
            </div>
            </nav>
        );
    }
}