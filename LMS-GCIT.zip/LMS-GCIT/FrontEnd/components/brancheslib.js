"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import {BranchListLib} from '../components/BranchListLib';

export class BranchesLib extends React.Component{

    render() {
        return(
            <div>
                <BranchListLib branchList = {this.props.branchList} />
            </div>
        );
    }
}

BranchesLib.propTypes = {
    branchList: PropTypes.array.isRequired
};