"use strict"

import React from 'react';
import {Link} from 'react-router-dom';

export class BorrowerHome extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            branch: ""
        };
    }

    render() {
        return(
            <div>
                <table className="table">
                    <thead>
                        <tr>
                            <th>Borrower Functions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <li><Link to="/borrower/checkOut" replace>Check Out Book</Link></li>
                        <li><Link to="/borrower/return" replace>Return Book</Link></li>
                    </tbody>    
                </table>
            </div>
        );
    }
}