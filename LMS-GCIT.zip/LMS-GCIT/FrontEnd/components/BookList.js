"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import BookActions from '../actions/bookActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class BookList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          isUpdate: -1,
          title: "",
          author: "",
          publisher: ""};
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleTitleChange = this.handleTitleChange.bind(this);
        this.handleAuthorChange = this.handleAuthorChange.bind(this);
        this.handlePublisherChange = this.handlePublisherChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleNew = this.handleNew.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleTitleChange(event) {
        this.setState({title: event.target.value});
    }
  
    handleAuthorChange(event) {
        this.setState({author: event.target.value});
    }
  
    handlePublisherChange(event) {
        this.setState({publisher: event.target.value});
    }

    handleSubmit(event) {
        var input = {
          "title":this.state.title,
          "author":{"authorName":this.state.author},
          "publisher":{"publisherName":this.state.publisher}
        };
        BookActions.newBook(input);
        alert('Book added: ' + this.state.title);
        event.preventDefault();
        this.closeModal();
    }

    handleUpdateSubmit(event) {
        var input = {
            "title":this.state.title,
            "author":{"authorName":this.state.author},
            "publisher":{"publisherName":this.state.publisher}
        };
        BookActions.updateBook(this.state.isUpdate, input);
        alert('Book updated: ' + this.state.title);
        event.preventDefault();
        this.closeModal();
    }

    handleNew(){
        this.setState({isUpdate: -1});
        this.openModal();
    }

    handleUpdate(id) {
        this.setState({isUpdate: id});
        this.openModal();
    }

    createBookRow(book){
        return (
            <tr key={book.bookId}>
                <td> {book.bookId} </td>
                <td> {book.title} </td>
                <td> {book.author.authorName} </td>
                <td> {book.publisher.publisherName} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleUpdate(book.bookId)} >Update</button>
                    <button className='btn btn-primary' onClick={() => BookActions.removeBook(book.bookId)} >Delete</button> 
                </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        BookActions.readBooks();
    }
    

    render() {
        return(
            <div>
              {this.state.isUpdate === -1 && <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Add Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for New Book</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleSubmit}>
                  <label>
                    Title:
                    <input type="text" title={this.state.title} onChange={this.handleTitleChange} />
                  </label>
                  <label>
                    Author:
                    <input type="text" author={this.state.author} onChange={this.handleAuthorChange} />
                  </label>
                  <label>
                    Publisher:
                    <input type="text" publisher={this.state.publisher} onChange={this.handlePublisherChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>}
              
              {this.state.isUpdate != -1 && <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for Update Book</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <label>
                    Title:
                    <input type="text" title={this.state.title} onChange={this.handleTitleChange} />
                  </label>
                  <label>
                    Author:
                    <input type="text" author={this.state.author} onChange={this.handleAuthorChange} />
                  </label>
                  <label>
                    Publisher:
                    <input type="text" publisher={this.state.publisher} onChange={this.handlePublisherChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>}

                <h1>Books</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>BookId</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Publisher</th>
                            <th><button
                            onClick = {this.handleNew}>Add</button></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.bookList.map(this.createBookRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

BookList.propTypes = {
    bookList: PropTypes.array.isRequired
};



