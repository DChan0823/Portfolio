"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import {BranchListCopies} from '../components/BranchListCopies';

export class BranchCopies extends React.Component{

    render() {
        return(
            <div>
                <BranchListCopies branchList = {this.props.branchList} />
            </div>
        );
    }
}

BranchCopies.propTypes = {
    branchList: PropTypes.array.isRequired
};