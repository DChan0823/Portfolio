"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import CopiesActions from '../actions/copiesActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class CopiesList extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          branchId: -1,
          bookId: -1,
          copies:""
        };
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleBranchChange = this.handleBranchChange.bind(this);
        this.handleCopiesChange = this.handleCopiesChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleNew = this.handleNew.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleBranchChange(event) {
        this.setState({branchId: event.target.value});
    }

    handleCopiesChange(event) {
        this.setState({copies: event.target.value});
    }

    handleSubmit(event) {
        CopiesActions.readBranchCopies(this.state.branchId);
        event.preventDefault();
        this.closeModal();
    }

    handleUpdateSubmit(event) {
        var input = {
          "noOfCopies":this.state.copies
        };
        CopiesActions.updateCopies(this.state.branchId, this.state.bookId, input);
        event.preventDefault();
        this.closeModal();
    }

    handleNew(){
        this.setState({isUpdate: -1});
        this.openModal();
    }

    handleUpdate(bkid) {
        this.setState({bookId: bkid});
        this.openModal();
    }

    createCopyRow(copy){
        return (
            <tr key={[copy.bkcpyId.bookId, copy.bkcpyId.branchId]}>
                <td> {copy.bkcpyId.bookId} </td>
                <td> {copy.noOfCopies} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleUpdate(copy.bkcpyId.bookId)} >Update</button>
                </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        CopiesActions.readBranchCopies(this.state.branchId);
    }
    

    render() {
        return(
            <div>
                <form onSubmit={this.handleSubmit}>
                  <label>
                     BranchId:
                    <input type="text" branchId={this.state.branchId} onChange={this.handleBranchChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              
              <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter Number of Copies values</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <label>
                    Number Of Copies:
                    <input type="text" name={this.state.name} onChange={this.handleCopiesChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>

                <h1>Book Copies</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>BookId</th>
                            <th>Number of Copies</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.copiesList.map(this.createCopyRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

CopiesList.propTypes = {
    copiesList: PropTypes.array.isRequired
};