"use strict"

import React from 'react';
import PropTypes from 'prop-types';
import BranchActions from '../actions/branchActions';
import Modal from 'react-modal'

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };

Modal.setAppElement('#app');

export class BranchListLib extends React.Component{

    constructor(props){
        super(props);
        this.state={
          modalIsOpen: false,
          isUpdate: -1,
          branchName: "",
          branchAddress: ""};
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleAddressChange = this.handleAddressChange.bind(this);
        this.handleUpdateSubmit = this.handleUpdateSubmit.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    openModal() {
        this.setState({modalIsOpen: true});
    }
  
    afterOpenModal() {
        this.subtitle.style.color = '#0000FF';
    }
  
    closeModal() {
        this.setState({modalIsOpen: false});
    }

    handleNameChange(event) {
        this.setState({name: event.target.value});
    }
  
    handleAddressChange(event) {
        this.setState({address: event.target.value});
    }

    handleUpdateSubmit(event) {
        var input = {
          "branchName":this.state.name,
          "branchAddress":this.state.address
        };
        BranchActions.updateBranch(this.state.isUpdate, input);
        alert('Branch updated: ' + this.state.name);
        event.preventDefault();
        this.closeModal();
    }

    handleUpdate(id) {
        this.setState({isUpdate: id});
        this.openModal();
    }

    createBranchRow(branch){
        return (
            <tr key={branch.branchId}>
                <td> {branch.branchId} </td>
                <td> {branch.branchName} </td>
                <td> {branch.branchAddress} </td>
                <td> <button className='btn btn-primary' onClick={() => this.handleUpdate(branch.branchId)} >Update</button>
                </td>
            </tr>
        );
    }

    UNSAFE_componentWillMount(){
        BranchActions.readBranches();
    }

    render() {
        return(
            <div>
              <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Update Modal">

                <h2 ref={subtitle => this.subtitle = subtitle}>Please enter values for Update Branch</h2>
                <button onClick={this.closeModal}>Cancel</button>
                <form onSubmit={this.handleUpdateSubmit}>
                  <label>
                    Branch Name:
                    <input type="text" name={this.state.name} onChange={this.handleNameChange} />
                  </label>
                  <label>
                    Branch Address:
                    <input type="text" address={this.state.address} onChange={this.handleAddressChange} />
                  </label>
                  <input type="submit" value="Submit" />
                </form>
              </Modal>

                <h1>Branches</h1>
                
                <table className="table">
                    <thead>
                        <tr>
                            <th>BranchId</th>
                            <th>Branch Name</th>
                            <th>Branch Address</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.branchList.map(this.createBranchRow, this)}
                    </tbody>
                </table>
            </div>
        );
    }
}

BranchListLib.propTypes = {
    branchList: PropTypes.array.isRequired
};