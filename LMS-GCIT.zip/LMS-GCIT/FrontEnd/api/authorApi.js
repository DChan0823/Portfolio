"use strict";
import Axios from 'axios'

const AuthorApi =  {
	getAllAuthors : () => {
	return Axios.get("http://localhost:8761/lms/admin/authors")
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getTheAuthor: (authorId) => {
		return Axios.get("http://localhost:8761/lms/admin/author/"+authorId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	createAuthor: (author) => {
		return Axios.post("http://localhost:8761/lms/admin/author", author)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	updateAuthor: (authorId, author) => {
		return Axios.put("http://localhost:8761/lms/admin/author/"+authorId, author)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deleteAuthor: (authorId) => {
		return Axios.delete("http://localhost:8761/lms/admin/author/"+authorId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = AuthorApi;