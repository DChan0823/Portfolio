"use strict";
import Axios from 'axios'

const PublisherApi =  {
	getAllPublishers : () => {
	return Axios.get("http://localhost:8761/lms/admin/publishers")
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getThePublisher: (pubId) => {
		return Axios.get("http://localhost:8761/lms/admin/publisher/"+pubId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	createPublisher: (pub) => {
		return Axios.post("http://localhost:8761/lms/admin/publisher", pub)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	updatePublisher: (pubId, pub) => {
		return Axios.put("http://localhost:8761/lms/admin/publisher/"+pubId, pub)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deletePublisher: (pubId) => {
		return Axios.delete("http://localhost:8761/lms/admin/publisher/"+pubId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = PublisherApi;