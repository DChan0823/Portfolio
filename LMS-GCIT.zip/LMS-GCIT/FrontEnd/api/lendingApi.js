"use strict";
import Axios from 'axios'

const LendingApi =  {

	getAllLoans : () => {
		return Axios.get("http://localhost:8761/lms/admin/loans")
			.then(response => response.data)
			.catch(function (error) {
				var err = error.data;
				return err;
			});
	},

	getBorrLoans: (cardNo) => {
		return Axios.get("http://localhost:8761/lms/borrower/loans/cardNo/"+cardNo)
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

    getTheLoan: (cardNo, branchId, bookId) => {
        return Axios.get("http://localhost:8761/lms/borrower/loans/cardNo/"+cardNo+"/branch/"+branchId+"/book/"+bookId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
    },

	createLoan: (cardNo, branchId, bookId, loan) => {
		return Axios.post("http://localhost:8761/lms/borrower/loans/cardNo/"+cardNo+"/branch/"+branchId+"/book/"+bookId, loan)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deleteLoan: (bookId, branchId, cardNo) => {
		return Axios.delete("http://localhost:8761/lms/borrower/loans/cardNo/"+cardNo+"/branch/"+branchId+"/book/"+bookId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = LendingApi;