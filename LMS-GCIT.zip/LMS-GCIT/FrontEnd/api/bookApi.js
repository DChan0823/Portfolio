"use strict";
import Axios from 'axios'

const BookApi =  {
	getAllBooks : () => {
	return Axios.get("http://localhost:8761/lms/admin/books")
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getTheBook: (bkId) => {
		return Axios.get("http://localhost:8761/lms/admin/book/"+bkId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	createBook: (bk) => {
		return Axios.post("http://localhost:8761/lms/admin/book", bk)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	updateBook: (bkId, bk) => {
		return Axios.put("http://localhost:8761/lms/admin/book/"+bkId, bk)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deleteBook: (bkId) => {
		return Axios.delete("http://localhost:8761/lms/admin/book/"+bkId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = BookApi;