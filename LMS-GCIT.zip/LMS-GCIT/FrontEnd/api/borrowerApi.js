"use strict";
import Axios from 'axios'

const BorrowerApi =  {
	getAllBorrowers : () => {
	return Axios.get("http://localhost:8761/lms/admin/borrowers")
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getTheBorrower: (cardNo) => {
		return Axios.get("http://localhost:8761/lms/admin/borrower/"+cardNo)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	createBorrower: (borr) => {
		return Axios.post("http://localhost:8761/lms/admin/borrower", borr)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	updateBorrower: (cardNo, borr) => {
		return Axios.put("http://localhost:8761/lms/admin/borrower/"+cardNo, borr)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deleteBorrower: (cardNo) => {
		return Axios.delete("http://localhost:8761/lms/admin/borrower/"+cardNo)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = BorrowerApi;