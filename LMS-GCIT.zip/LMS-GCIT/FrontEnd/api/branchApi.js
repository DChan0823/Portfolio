"use strict";
import Axios from 'axios'

const BranchApi =  {
	getAllBranches : () => {
	return Axios.get("http://localhost:8761/lms/admin/branches")
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getTheBranch: (branchId) => {
		return Axios.get("http://localhost:8761/lms/admin/branch/"+branchId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	createBranch: (branch) => {
		return Axios.post("http://localhost:8761/lms/admin/branch", branch)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	updateBranch: (branchId, branch) => {
		return Axios.put("http://localhost:8761/lms/admin/branch/"+branchId, branch)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deleteBranch: (branchId) => {
		return Axios.delete("http://localhost:8761/lms/admin/branch/"+branchId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = BranchApi;