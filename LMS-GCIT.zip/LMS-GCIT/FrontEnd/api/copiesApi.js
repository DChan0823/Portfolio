"use strict";
import Axios from 'axios'

const CopiesApi =  {

    getBranchCopies: (branchId) => {
        return Axios.get("http://localhost:8761/lms/librarian/branch/"+branchId+"/bookId")
            .then(response => response.data)
            .catch(function (error) {
                return error.data;
                }
            )
    },

	getTheCopies: (branchId, bookId) => {
		return Axios.get("http://localhost:8761/lms/librarian/branch/"+branchId+"/bookId/"+bookId)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
    },
    
	updateCopies: (branchId, bookId, copies) => {
		return Axios.put("http://localhost:8761/lms/librarian/branch/"+branchId+"/bookId/"+bookId, copies)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = CopiesApi;