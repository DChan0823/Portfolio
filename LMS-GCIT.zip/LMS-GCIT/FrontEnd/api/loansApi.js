"use strict";
import Axios from 'axios'

const LoansApi =  {

	getBorrLoans: (cardNo) => {
		return Axios.get("http://localhost:8761/lms/admin/loans/cardNo/"+cardNo)
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getAllLoans : () => {
	return Axios.get("http://localhost:8761/lms/admin/loans")
		.then(response => response.data)
		.catch(function (error) {
			var err = error.data;
			return err;
		});
	},

	getTheLoan: (bookId, branchId, cardNo) => {
		return Axios.get("http://localhost:8761/lms/admin/loan/book/"+bookId+"/branch/"+branchId+"/borrower/"+cardNo)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	createLoan: (loan) => {
		return Axios.post("http://localhost:8761/lms/admin/loans", loan)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	updateLoan: (bookId, branchId, cardNo, loan) => {
		return Axios.put("http://localhost:8761/lms/admin/loan/book/"+bookId+"/branch/"+branchId+"/borrower/"+cardNo, loan)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	},

	deleteLoan: (bookId, branchId, cardNo) => {
		return Axios.delete("http://localhost:8761/lms/admin/loan/book/"+bookId+"/branch/"+branchId+"/borrower/"+cardNo)
			.then(response => response.data)
			.catch(function (error) {
				return error.data;
			}
		);
	}
}

module.exports = LoansApi;