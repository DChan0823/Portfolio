import Dispatcher from '../dispatcher/appDispatcher';
import {EventEmitter} from 'events';


const CHANGE_EVENT = 'change';

let _returnStore = {
  returns: []
};

class ReturnStoreClass extends EventEmitter{

    addChangeListener(cb){
        this.on(CHANGE_EVENT, cb);
    }

    removeChangeListener(cb){
        this.removeListener(CHANGE_EVENT, cb);
    }

    emitChange(){
        this.emit(CHANGE_EVENT);
    }

    getAllReturns(){
        return _returnStore.returns;
    }
}

const ReturnStore = new ReturnStoreClass();

Dispatcher.register( (action) => {

    switch (action.actionType){
        
        case 'read_Brloans':
            _returnStore.returns = action.data;
            ReturnStore.emitChange();
            break;
        case 'read_loan':
            _returnStore.returns = action.data;
            ReturnStore.emitChange();
            break;
        case 'create_loan':
            _returnStore.returns=_returnStore.returns.concat([action.data]);
            ReturnStore.emitChange();
            break;
        case 'delete_loan':
            var i = 0;
            for(i = 0; i < _returnStore.returns.length; i++){
                if((_returnStore.returns[i].bklnId.bookId === action.data.bklnId.bookId) 
                && (_returnStore.returns[i].bklnId.branchId === action.data.bklnId.branchId) 
                && (_returnStore.returns[i].bklnId.cardNo === action.data.bklnId.cardNo)){
                    _returnStore.returnss.splice(i, 1);
                }
            }
            ReturnStore.emitChange();
            break;
        default:
            return;
    }
});

export default ReturnStore;