import Dispatcher from '../dispatcher/appDispatcher';
import {EventEmitter} from 'events';


const CHANGE_EVENT = 'change';

let _authorStore = {
  authors: []
};

class AuthorStoreClass extends EventEmitter{

    addChangeListener(cb){
        this.on(CHANGE_EVENT, cb);
    }

    removeChangeListener(cb){
        this.removeListener(CHANGE_EVENT, cb);
    }

    emitChange(){
        this.emit(CHANGE_EVENT);
    }

    getAllAuthors(){
        return _authorStore.authors;
    }
}

const AuthorStore = new AuthorStoreClass();

Dispatcher.register( (action) => {

    switch (action.actionType){
        case 'read_authors':
            _authorStore.authors = action.data;
            AuthorStore.emitChange();
            break;
        case 'read_author':
            break;
        case 'create_author':
            _authorStore.authors=_authorStore.authors.concat([action.data]);
            AuthorStore.emitChange();
            break;
        case 'update_author':
            var i = 0;
            for(i = 0; i < _authorStore.authors.length; i++){
                if(_authorStore.authors[i].authorId === action.data.authorId){
                    _authorStore.authors[i] = action.data;
                }
            }
            AuthorStore.emitChange();
            break;
        case 'delete_author':
            for(i = 0; i < _authorStore.authors.length; i++){
                if(_authorStore.authors[i].authorId === action.data){
                    _authorStore.authors.splice(i, 1);
                }
            }
            AuthorStore.emitChange();
            break;
        default:
            return;
    }
});

export default AuthorStore;