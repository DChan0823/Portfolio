import Dispatcher from '../dispatcher/appDispatcher';
import {EventEmitter} from 'events';


const CHANGE_EVENT = 'change';

let _branchStore = {
  branches: []
};

class BranchStoreClass extends EventEmitter{

    addChangeListener(cb){
        this.on(CHANGE_EVENT, cb);
    }

    removeChangeListener(cb){
        this.removeListener(CHANGE_EVENT, cb);
    }

    emitChange(){
        this.emit(CHANGE_EVENT);
    }

    getAllBranches(){
        return _branchStore.branches;
    }
}

const BranchStore = new BranchStoreClass();

Dispatcher.register( (action) => {

    switch (action.actionType){
        case 'read_branches':
            _branchStore.branches = action.data;
            BranchStore.emitChange();
            break;
        case 'read_branch':
            break;
        case 'create_branch':
            _branchStore.branches=_branchStore.branches.concat([action.data]);
            BranchStore.emitChange();
            break;
        case 'update_branch':
            var i = 0;
            for(i = 0; i < _branchStore.branches.length; i++){
                if(_branchStore.branches[i].branchId === action.data.branchId){
                    _branchStore.branches[i] = action.data;
                }
            }
            BranchStore.emitChange();
            break;
        case 'delete_branch':
            for(i = 0; i < _branchStore.branches.length; i++){
                if(_branchStore.branches[i].branchId === action.data){
                    _branchStore.branches.splice(i, 1);
                }
            }
            BranchStore.emitChange();
            break;
        default:
            return;
    }
});

export default BranchStore;