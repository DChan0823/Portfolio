import Dispatcher from '../dispatcher/appDispatcher';
import {EventEmitter} from 'events';


const CHANGE_EVENT = 'change';

let _loansStore = {
  loans: []
};

class LoansStoreClass extends EventEmitter{

    addChangeListener(cb){
        this.on(CHANGE_EVENT, cb);
    }

    removeChangeListener(cb){
        this.removeListener(CHANGE_EVENT, cb);
    }

    emitChange(){
        this.emit(CHANGE_EVENT);
    }

    getAllLoans(){
        return _loansStore.loans;
    }
}

const LoansStore = new LoansStoreClass();

Dispatcher.register( (action) => {

    switch (action.actionType){
        case 'read_loans':
            _loansStore.loans = action.data;
            LoansStore.emitChange();
            break;
        case 'read_Brloans':
            _loansStore.loans = action.data;
            LoansStore.emitChange();
            break;
        case 'create_loan':
            _loansStore.loans=_loansStore.loans.concat([action.data]);
            LoansStore.emitChange();
            break;
        case 'update_loan':
            var i = 0;
            for(i = 0; i < _loansStore.loans.length; i++){
                if( (_loansStore.loans[i].bklnId.bookId === action.data.bklnId.bookId) 
                    && (_loansStore.loans[i].bklnId.branchId === action.data.bklnId.branchId) 
                    && (_loansStore.loans[i].bklnId.cardNo === action.data.bklnId.cardNo)){
                    _loansStore.loans[i] = action.data;
                }
            }
            LoansStore.emitChange();
            break;
        case 'delete_loan':
            for(i = 0; i < _loansStore.loans.length; i++){
                if((_loansStore.loans[i].bookId === action.data.bookId) 
                && (_loansStore.loans[i].branchId === action.data.branchId) 
                && (_loansStore.loans[i].cardNo === action.data.cardNo)){
                    _loansStore.loans.splice(i, 1);
                }
            }
            LoansStore.emitChange();
            break;
        default:
            return;
    }
});

export default LoansStore;