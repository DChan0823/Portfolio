import Dispatcher from '../dispatcher/appDispatcher';
import {EventEmitter} from 'events';


const CHANGE_EVENT = 'change';

let _copiesStore = {
  copies: []
};

class CopiesStoreClass extends EventEmitter{

    addChangeListener(cb){
        this.on(CHANGE_EVENT, cb);
    }

    removeChangeListener(cb){
        this.removeListener(CHANGE_EVENT, cb);
    }

    emitChange(){
        this.emit(CHANGE_EVENT);
    }

    getAllCopies(){
        return _copiesStore.copies;
    }
}

const CopiesStore = new CopiesStoreClass();

Dispatcher.register( (action) => {

    switch (action.actionType){
        case 'read_brCopies':
            _copiesStore.copies = action.data;
            CopiesStore.emitChange();
            break;
        case 'read_copies':
            _copiesStore.copies = action.data;
            CopiesStore.emitChange();
            break;
        case 'update_copies':
            var i = 0;
            for(i = 0; i < _copiesStore.copies.length; i++){
                if( (_copiesStore.copies[i].bkcpyId.branchId === action.data.bkcpyId.branchId)
                    && (_copiesStore.copies[i].bkcpyId.bookId === action.data.bkcpyId.bookId) ){
                    _copiesStore.copies[i] = action.data;
                }
            }
            CopiesStore.emitChange();
            break;
        default:
            return;
    }
});

export default CopiesStore;