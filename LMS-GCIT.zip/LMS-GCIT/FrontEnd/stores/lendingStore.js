import Dispatcher from '../dispatcher/appDispatcher';
import {EventEmitter} from 'events';


const CHANGE_EVENT = 'change';

let _lendingStore = {
  lendings: []
};

class LendingStoreClass extends EventEmitter{

    addChangeListener(cb){
        this.on(CHANGE_EVENT, cb);
    }

    removeChangeListener(cb){
        this.removeListener(CHANGE_EVENT, cb);
    }

    emitChange(){
        this.emit(CHANGE_EVENT);
    }

    getAllLendings(){
        return _lendingStore.lendings;
    }
}

const LendingStore = new LendingStoreClass();

Dispatcher.register( (action) => {

    switch (action.actionType){
        
        case 'read_Brloans':
            _lendingStore.lendings = action.data;
            LendingStore.emitChange();
            break;
        case 'read_loan':
            _lendingStore.lendings = action.data;
            LendingStore.emitChange();
            break;
        case 'create_loan':
            _lendingStore.lendings=_lendingStore.lendings.concat([action.data]);
            LendingStore.emitChange();
            break;
        case 'delete_loan':
            var i = 0;
            for(i = 0; i < _lendingStore.lendings.length; i++){
                if((_lendingStore.lendings[i].bklnId.bookId === action.data.bklnId.bookId) 
                && (_lendingStore.lendings[i].bklnId.branchId === action.data.bklnId.branchId) 
                && (_lendingStore.lending[i].bklnId.cardNo === action.data.bklnId.cardNo)){
                    _lendingStore.lendings.splice(i, 1);
                }
            }
            LendingStore.emitChange();
            break;
        default:
            return;
    }
});

export default LendingStore;