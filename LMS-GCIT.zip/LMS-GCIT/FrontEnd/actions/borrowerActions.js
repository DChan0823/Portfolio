import BorrowerApi from '../api/borrowerApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const BorrowerActions = {
    readBorrowers: () => {
        BorrowerApi.getAllBorrowers()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_borrowers',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readABorrower: (cardNo) => {
        BorrowerApi.getTheBorrower(cardNo)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_borrower',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newBorrower: (borr) => {
        BorrowerApi.createBorrower(borr)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_borrower',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updateBorrower: (cardNo, borr) => {
        BorrowerApi.updateBorrower(cardNo, borr)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_borrower',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeBorrower: (cardNo) => {
        BorrowerApi.deleteBorrower(cardNo);
        Dispatcher.dispatch({
                actionType: 'delete_borrower',
                data: cardNo 
        });
    }
}

module.exports = BorrowerActions;