import BranchApi from '../api/branchApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const BranchActions = {
    readBranches: () => {
        BranchApi.getAllBranches()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_branches',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readABranch: (branchId) => {
        BranchApi.getTheBranch(branchId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_branch',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newBranch: (branch) => {
        BranchApi.createBranch(branch)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_branch',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updateBranch: (branchId, branch) => {
        BranchApi.updateBranch(branchId, branch)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_branch',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeBranch: (branchId) => {
        BranchApi.deleteBranch(branchId);
        Dispatcher.dispatch({
                actionType: 'delete_branch',
                data: branchId 
        });
    }
}

module.exports = BranchActions;