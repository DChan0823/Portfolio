import ReturnApi from '../api/returnApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const ReturnActions = {
    readBorrLoans: (cardNo) => {
        ReturnApi.getBorrLoans(cardNo)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_Brloans',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readLoans: () => {
        ReturnApi.getAllLoans()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_loans',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readTheLoan: (cardNo, branchId, bookId) => {
        ReturnApi.getTheLoan(cardNo, branchId, bookId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newLoan: (cardNo, branchId, bookId, loan) => {
        ReturnApi.createLoan(cardNo, branchId, bookId, loan)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeLoan: (bookId, branchId, cardNo) => {
        ReturnApi.deleteLoan(bookId, branchId, cardNo);
        Dispatcher.dispatch({
                actionType: 'delete_loan',
                data: bookId, branchId, cardNo 
        });
    }
}

module.exports = ReturnActions;