
import BookApi from '../api/bookApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const BooksActions = {
    readBooks: () => {
        BookApi.getAllBooks()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_books',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readABook: (bookId) => {
        BookApi.getTheBook(bookId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_book',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newBook: (book) => {
        BookApi.createBook(book)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_book',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updateBook: (bookId, book) => {
        BookApi.updateBook(bookId, book)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_book',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeBook: (bookId) => {
        BookApi.deleteBook(bookId);
        Dispatcher.dispatch({
                actionType: 'delete_book',
                data: bookId 
        });
    }
}

module.exports = BooksActions;