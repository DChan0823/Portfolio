import PublisherApi from '../api/publisherApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const PublishersActions = {
    readPublishers: () => {
        PublisherApi.getAllPublishers()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_publishers',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readAPublisher: (pubId) => {
        PublisherApi.getThePublisher(pubId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_publisher',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newPublisher: (pub) => {
        PublisherApi.createPublisher(pub)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_publisher',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updatePublisher: (pubId, pub) => {
        PublisherApi.updatePublisher(pubId, pub)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_publisher',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removePublisher: (pubId) => {
        PublisherApi.deletePublisher(pubId);
        Dispatcher.dispatch({
                actionType: 'delete_publisher',
                data: pubId 
        });
    }
}

module.exports = PublishersActions;