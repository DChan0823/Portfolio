import AuthorApi from '../api/authorApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const AuthorsActions = {
    readAuthors: () => {
        AuthorApi.getAllAuthors()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_authors',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readAnAuthor: (authorId) => {
        AuthorApi.getTheAuthor(authorId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_author',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newAuthor: (author) => {
        AuthorApi.createAuthor(author)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_author',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updateAuthor: (authorId, author) => {
        AuthorApi.updateAuthor(authorId, author)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_author',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeAuthor: (authorId) => {
        AuthorApi.deleteAuthor(authorId);
        Dispatcher.dispatch({
                actionType: 'delete_author',
                data: authorId 
        });
    }
}

module.exports = AuthorsActions;