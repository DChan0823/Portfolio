import LendingApi from '../api/lendingApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const LendingActions = {
    readBorrLoans: (cardNo) => {
        LendingApi.getBorrLoans(cardNo)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_Brloans',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readLoans: () => {
        LendingApi.getAllLoans()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_loans',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readTheLoan: (cardNo, branchId, bookId) => {
        LendingApi.getTheLoan(cardNo, branchId, bookId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newLoan: (cardNo, branchId, bookId, loan) => {
        LendingApi.createLoan(cardNo, branchId, bookId, loan)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeLoan: (bookId, branchId, cardNo) => {
        LendingApi.deleteLoan(bookId, branchId, cardNo);
        Dispatcher.dispatch({
                actionType: 'delete_loan',
                data: bookId, branchId, cardNo 
        });
    }
}

module.exports = LendingActions;