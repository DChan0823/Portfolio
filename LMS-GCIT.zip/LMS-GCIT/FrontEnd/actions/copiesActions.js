import CopiesApi from '../api/copiesApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const CopiesActions = {
    
    readBranchCopies: (branchId) => {
        CopiesApi.getBranchCopies(branchId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_brCopies',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readACopies: (branchId, bookId) => {
        CopiesApi.getTheCopies(branchId, bookId)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_copies',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updateCopies: (branchId, bookId, copies) => {
        CopiesApi.updateCopies(branchId, bookId, copies)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_copies',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    }
}

module.exports = CopiesActions;