import LoansApi from '../api/loansApi';
import Dispatcher from '../dispatcher/appDispatcher';

//Here add all crud actions for Books

const LoansActions = {
    readBorrLoans: (cardNo) => {
        LoansApi.getBorrLoans(cardNo)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_Brloans',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readLoans: () => {
        LoansApi.getAllLoans()
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_loans',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    readALoan: (bookId, branchId, cardNo) => {
        LoansApi.getTheLoan(bookId, branchId, cardNo)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'read_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    newLoan: (loan) => {
        LoansApi.createLoan(loan)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'create_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    updateLoan: (bookId, branchId, cardNo, loan) => {
        LoansApi.updateLoan(bookId, branchId, cardNo, loan)
        .then(res => {
            Dispatcher.dispatch({
                actionType: 'update_loan',
                data: res 
            });
        })
        .catch(err => {
            console.log(err.data);
        });
    },

    removeLoan: (bookId, branchId, cardNo) => {
        LoansApi.deleteLoan(bookId, branchId, cardNo);
        Dispatcher.dispatch({
                actionType: 'delete_loan',
                data: bookId, branchId, cardNo 
        });
    }
}

module.exports = LoansActions;