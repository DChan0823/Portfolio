package com.gcit.lms.borrower_v2.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gcit.lms.borrower_v2.model.Book;

@Repository
public interface BookDao extends JpaRepository<Book, Long> {

}
