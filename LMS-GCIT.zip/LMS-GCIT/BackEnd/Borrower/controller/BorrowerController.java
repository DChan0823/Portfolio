package com.gcit.lms.borrower_v2.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import com.gcit.lms.borrower_v2.dao.BorrowerDao;
import com.gcit.lms.borrower_v2.model.Borrower;
import com.gcit.lms.borrower_v2.dao.BookLoansDao;
import com.gcit.lms.borrower_v2.model.BookLoans;
import com.gcit.lms.borrower_v2.model.BookLoansId;

@CrossOrigin
@RestController
//@RequestMapping("/lms/borrower")
public class BorrowerController {
	
	@Autowired
	private BookLoansDao blDao;
	
	@GetMapping("/loans/cardNo/{cardNo}")
	public List<BookLoans> getBorrLoans(@PathVariable Long cardNo) {
		
		return blDao.findByCardNo(cardNo);
	}
	
	@GetMapping("/loans/cardNo/{cardNo}/branch/{branchId}")
	public List<BookLoans> getBorrBranchLoans(@PathVariable Long cardNo, @PathVariable Long branchId) {
		
		return blDao.findByCardNo(cardNo);
	}
	
	@GetMapping("/loans/cardNo/{cardNo}/branch/{branchId}/book/{bookId}")
	public Optional<BookLoans> getTheBookLoan(@PathVariable Long cardNo, @PathVariable Long branchId, @PathVariable Long bookId) {
		
		return blDao.findByBookLoansId(bookId, branchId, cardNo);
	}
	
	//@PutMapping("/loans/cardNo/{cardNo}/branch/{branchId}/book/{bookId}")
	@PostMapping("/loans/cardNo/{cardNo}/branch/{branchId}/book/{bookId}")
	public BookLoans addTheLoan(@PathVariable Long cardNo, @PathVariable Long branchId, @PathVariable Long bookId, @Valid @RequestBody BookLoans loan) {//@Valid @RequestBody String dateOut, @Valid @RequestBody String dueDate) {
		
		BookLoansId blId = new BookLoansId();
		
		blId.setBookId(bookId);
		blId.setBranchId(branchId);
		blId.setCardNo(cardNo);
		
		//BookLoans loan = blDao.findByBookLoansId(bookId, branchId, cardNo).get();
		//loan.setDateOut(dateOut);
		//loan.setDueDate(dueDate);
		loan.setBklnId(blId);
		
		return blDao.save(loan);
	}
	
	@DeleteMapping("/loans/cardNo/{cardNo}/branch/{branchId}/book/{bookId}")
	public Optional<BookLoans> deleteTheLoan(@PathVariable Long cardNo, @PathVariable Long branchId, @PathVariable Long bookId) {
		//BookLoansId blId = new BookLoansId();
		
		//blId.setBookId(bookId);
		//blId.setBranchId(branchId);
		//blId.setCardNo(cardNo);
		
		Optional<BookLoans> temp = blDao.findByBookLoansId(bookId, branchId, cardNo);
		
		blDao.deleteByBookLoansId(bookId, branchId, cardNo);
		
		return temp;
	}
}
