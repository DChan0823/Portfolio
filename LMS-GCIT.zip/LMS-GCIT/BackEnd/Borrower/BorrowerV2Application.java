package com.gcit.lms.borrower_v2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BorrowerV2Application {

	public static void main(String[] args) {
		SpringApplication.run(BorrowerV2Application.class, args);
	}
}
