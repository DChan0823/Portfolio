package com.gcit.lms.librarian_v2.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import com.gcit.lms.librarian_v2.dao.LibraryBranchDao;
import com.gcit.lms.librarian_v2.model.LibraryBranch;
import com.gcit.lms.librarian_v2.dao.BookCopiesDao;
import com.gcit.lms.librarian_v2.model.BookCopies;
import com.gcit.lms.librarian_v2.model.BookCopiesId;

@CrossOrigin
@RestController
//@RequestMapping("/lms/librarian")
public class LibrarianController {
	
	@Autowired
	private LibraryBranchDao branchDao;
	
	@Autowired
	private BookCopiesDao bcDao;
	
	@GetMapping("/branch")
	public List<LibraryBranch> getBranches(){
		return branchDao.findAll();
	}
	
	@GetMapping("/branch/{branchId}")
	public Optional<LibraryBranch> getTheBranch(@PathVariable Long branchId) {
		
		return branchDao.findById(branchId);
	}
	
	@PutMapping("/branch/{branchId}")
	public LibraryBranch editBranch(@PathVariable Long branchId, @Valid @RequestBody LibraryBranch branch) {
		
		branch.setBranchId(branchId);
		
		return branchDao.save(branch);
	}
	
	@GetMapping("/branch/{branchId}/bookId")
	public List<BookCopies> getBranchCopies(@PathVariable Long branchId){
		
		return bcDao.findByBranchId(branchId);
	}
	
	@GetMapping("/branch/{branchId}/bookId/{bookId}")
	public Optional<BookCopies> getBookCopies(@PathVariable Long branchId, @PathVariable Long bookId){
		
		return bcDao.findByBookCopyId(bookId, branchId);
	}
	
	@PutMapping("/branch/{branchId}/bookId/{bookId}")
	public BookCopies editBookCopy(@PathVariable Long branchId, @PathVariable Long bookId, @Valid @RequestBody BookCopies copies) {
		
		BookCopiesId bcId = new BookCopiesId();
		
		bcId.setBranchId(branchId);
		bcId.setBookId(bookId);
		
		//BookCopies copies = bcDao.findByBookCopyId(bcId).get();
		
		copies.setBkcpyId(bcId);
		
		return bcDao.save(copies);
	}
}
