/****************************************************************
Program Name: main.cpp (main for WoWPlayerDatabase Project)
Programmer's Name: Derek Chan
****************************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>
#include <vector>
#include "PlayerData.h"
#include "BinarySearchTree.h"
#include "HashTable.h"
#include "HashBucket.h"
#include "FileIO.h"
#include "SystemOutput.h"
using namespace std;

typedef PlayerData* PD_PTR;

void displayPD_PTR(PD_PTR &ptrPD);
int comparePlayerNames(const PD_PTR &left, const PD_PTR &right);
int hashPlayerName(const PD_PTR &player);
int HashString(const string & key);

int main()
{
	BinarySearchTree<PD_PTR>* tree;
	HashTable <PD_PTR>* table;

	FileIO* ioFile = new FileIO(hashPlayerName, comparePlayerNames, displayPD_PTR);
	
	ioFile->readIn();

	tree = ioFile->getTreePtr();
	table = ioFile->getTablePtr();

	SystemOutput* outScreen = new SystemOutput(tree, table, ioFile, displayPD_PTR);

	outScreen->intro();
	outScreen->menu();

	delete tree;
	delete table;

	system("pause");
	return 0;
}

void displayPD_PTR(PD_PTR &ptrPD)
{
	ptrPD->write(cout);
}

//*************************************************************************
//* calls on HashString() to return a unique int for hashtables.          *
//*************************************************************************
int hashPlayerName(const PD_PTR &player)
{
	return HashString(player->getName());
}

//*************************************************************************
//* Takes a string and retruns a unique int based off the string. Int will*
//* which will be used in hashTable.                                      *
//*************************************************************************
int HashString(const string & key)
{
	unsigned int k, retVal = 0;

	//creats keys only off first 5 chars
	for (k = 0; k < key.length() && k < 5; k++)
		retVal = 37 * retVal + key[k];


	return retVal;
}

//*************************************************************************
//* Will compare ColorNames, returning -1 if left is smaller then right,  *
//* returning 1 if right is smaller, and a 0 if they are the same.        *
//*************************************************************************
int comparePlayerNames(const PD_PTR &left, const PD_PTR &right)
{
	if (left->getName() < right->getName())
		return -1;
	if (left->getName() > right->getName())
		return 1;
	return 0;
}

