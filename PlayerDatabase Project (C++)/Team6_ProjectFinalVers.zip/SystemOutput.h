/****************************************************************
Program Name: SystemOutput.h
Programmer's Name: Derek Chan
****************************************************************/
#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include "PlayerData.h"
#include "BinarySearchTree.h"
#include "HashTable.h"
#include "HashBucket.h"
#include "FileIO.h"
using namespace std;

typedef PlayerData* PD_PTR;

class SystemOutput
{
private:
	BinarySearchTree<PD_PTR>* tree;
	HashTable<PD_PTR>* table;
	FileIO* inOutFile;

	void(*pDisplay)(PD_PTR &ptrPD);
public:

	SystemOutput(BinarySearchTree<PD_PTR>* ptree, HashTable<PD_PTR> *phash, FileIO* ioFile, void displayPD_PTR(PD_PTR &ptrPD))
	{
		tree = ptree;
		table = phash;
		inOutFile = ioFile;
		pDisplay = displayPD_PTR;
	}

	~SystemOutput()
	{
	}

	void intro()
	{
		cout << "\nWelcome to the World of Warcraft Player Database!\n\n";
	}

	void menu()
	{
		int userInput;
		char userSubInput, userRemoveInput;
		string newName, newFaction, newClass, newRace;
		string inputString;
		PlayerData* newPlayer;
		PlayerData* targetPlayer;
		PlayerData* foundPlayer;

		do
		{
			cout << "\nMENU\n" << "---------------------------------------\n";
			cout << "1. Add New Player Data\n" << "2. Delete Player Data\n";
			cout << "3. Find Player Data\n" << "4. List Player Data in Hash Table Sequence\n";
			cout << "5. List Data in Key Sequence (Alphabetically)\n" << "6. Print Indented Tree\n";
			cout << "7. Write Data to File\n" << "8. Print Efficiency\n" << "9. Quit\n";

			cin >> userInput;

			switch (userInput)
			{
			case 1:
				do
				{
					cin.ignore();
					cout << endl << "Please enter name of new player: ";
					getline(cin, newName);
					cout << endl << "Please enter faction of new player: ";
					getline(cin, newFaction);
					cout << endl << "Please enter class of new player: ";
					getline(cin, newClass);
					cout << endl << "Please enter race of new player: ";
					getline(cin, newRace);

					newPlayer = new PlayerData(newName, newFaction, newClass, newRace);

					if (!table->insert(newPlayer))
					{
						cout << endl << newName << " insert to Hash Table NOT successful.\n";
						cout << newName << " Not Inserted into Tree\n\n";
					}
					else
					{
						tree->insert(newPlayer);
						cout << endl << newName << " insert to tree successful.\n";
					}

					cout << "\nDo you want to add another player? (Y or N)\n";
					cin >> userSubInput;

					if (userSubInput == 'N')
					{
						cout << "\nPrinting Current Data\n";
						tree->inOrder(pDisplay);
					}
				} while (userSubInput == 'Y');

				break;
			case 2:
				do
				{
					cout << endl << "Please enter name of player to remove: ";
					cin.ignore();
					getline(cin, inputString);

					targetPlayer = new PlayerData(inputString, inputString, inputString, inputString);

					if (table->remove(targetPlayer))
					{
						cout << inputString << " removed from Hash Table.\n";
						tree->remove(targetPlayer);
						cout << inputString << " removed from BST.\n";
					}
					else
					{
						cout << inputString << " could Not removed from BST.\n";
					}

					delete targetPlayer;

					cout << "\nDo you want to remove another player? (Y or N)\n";
					cin >> userRemoveInput;

					if (userRemoveInput == 'N')
					{
						cout << "\nPrinting Current Data\n";
						tree->inOrder(pDisplay);
					}
				} while (userRemoveInput == 'Y');

				break;
			case 3:
				do
				{
					cin.ignore();
					cout << endl << "Please enter name of player to search: ";
					getline(cin, inputString);

					targetPlayer = new PlayerData(inputString, inputString, inputString, inputString);

					if (tree->getEntry(targetPlayer, foundPlayer))
					{
						cout << "Found " << inputString << " in tree:" << endl;
						foundPlayer->write(cout);
					}
					else
						cout << inputString << " not found in tree.\n";

					if (table->getEntry(targetPlayer, foundPlayer))
					{
						cout << "Found " << inputString << " in hash table:" << endl;
						foundPlayer->write(cout);
					}
					else
						cout << inputString << " not found in hash table\n";

					cout << "Do you want to search another player? (Y or N)\n";
					cin >> userRemoveInput;

				} while (userRemoveInput == 'Y');
					
				break;
			case 4:
				cout << endl << "Listing Data in Hash Table Sequence: \n";
				table->displayHashTable(cout);

				break;
			case 5:
				cout << endl << "Listing Data in Key Sequence (alphabetical): \n";
				tree->inOrder(pDisplay);

				break;
			case 6:
				cout << endl << "Printing indented tree: \n";
				tree->printIndented();

				break;
			case 7:
				cout << endl << "Initializing Write to File... \n";
				inOutFile->writeToFileBreadth();



				break;
			case 8:
				cout << endl << "Displaying Efficiency Statistics: \n";
				table->displayStatistics();

				break;
			case 9:
				cout << endl << "Quitting Program...\n";
				cout << endl << "Saving Data...\n";
				inOutFile->writeToFileBreadth();

				return;
			default:
				break;
			} //end of switch
		} while (userInput != 9); //post-condition of do-while loop
	}
};

