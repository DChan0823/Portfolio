/*Brett Witten
  Binary Search Tree for Team Project*/

#ifndef _BST
#define _BST

#include <ostream>
#include "BinaryNode.h"

template<class ItemType>
class BST
{
private:
	BinaryNode<ItemType>* rootPtr;
	int count;

	//delete all nodes from subtree
	void destoryTree(BinaryNode<ItemType>*);
	//copy from the tree rooted at nodePtr and returns a pointer to the copy
	BinaryNode<ItemType>* copyTree(const BinaryNode<ItemType>* nodePtr);
	//internal insert node
	BinaryNode<ItemType>* _insert(BinaryNode<ItemType>* nodePtr, BinaryNode<ItemType>* newNode);
	//internal remove node
	BinaryNode<ItemType>* _remove(BinaryNode<ItemType>* nodePtr, const ItemType target, bool & success);
	//internal delete target node, to be called by internal remove
	BinaryNode<ItemType>* deleteNode(BinaryNode<ItemType>* targetNodePtr);
	//remove leftmost node in left subtree
	BinaryNode<ItemType>* removeLeftmostNode(BinaryNode<ItemType>* nodePtr, ItemType & successor);
	// search for target node
	BinaryNode<ItemType>* findNode(BinaryNode<ItemType>* treePtr, const ItemType & target) const;

	// internal traverse
	void _preorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const;
	void _inorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const;
	void _postorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const;

public:
	BST() : rootPtr(0), count(0) {}
	~BST();
	
	bool insert(ItemType&);
	bool remove(ItemType&);
	bool isEmpty() const				{ return count == 0; }
	int size() const					{ return count; }
	void clear()						{ destoryTree(rootPtr); rootPtr = 0; count = 0; }
	bool getEntry(const ItemType& anEntry, ItemType& returnItem) const;

	void preOrder(void visit(ItemType &)) const		{ _preorder(visit, rootPtr); }
	void inOrder(void visit(ItemType &)) const		{ _inorder(visit, rootPtr); }
	void postOrder(void visit(ItemType &)) const	{ _postorder(visit, rootPtr); }

	void printIndented(ostream&) const;
	void printAlph(ostream&) const;
	void printBreath(ostream&) const;
};

template<class ItemType>
void BST<ItemType>::_preorder(void visit(ItemType &), BinaryNode<ItemType>* nodePtr) const
{
	if (nodePtr != 0)
	{
		ItemType item = nodePtr->getItem();
		visit(item);
		_preorder(visit, nodePtr->getLeftPtr());
		_preorder(visit, nodePtr->getRightPtr());
	}
}
#endif