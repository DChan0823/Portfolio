// Linked list implementation of queue ADT
// Created by Frank M. Carrano and Tim Henry.
// Modified by CNguyen
// Completed by Matthew Byers
// Date: 2/3/2015

#ifndef _LINKED_QUEUE
#define _LINKED_QUEUE

#include "QueueInterface.h"
#include "Node.h"

template<class ItemType>
class LinkedQueue : public QueueInterface<ItemType>
{
private:
   Node<ItemType>* backPtr;
   Node<ItemType>* frontPtr;
   int count;

public:
	//default constructor
	LinkedQueue();
	//Copy constructor
	LinkedQueue (const LinkedQueue& aQueue);
	//Destructor
	~LinkedQueue();
	//getter for size/count of queue
	int size() const {return count;}
	//returns true if queue is empty
	bool isEmpty() const {return (count == 0);}
	//Add node to back of queue
	bool enqueue(const ItemType& newEntry);
	//removes item from font of queue
	bool dequeue();
	//returns first element of queue
	ItemType peekFront() const {return frontPtr->getItem();}
}; 

//****************************************************************
//* Initializes all private variables/pointers to 0 or Null.     *
//****************************************************************
template<class ItemType>
LinkedQueue<ItemType>::LinkedQueue() { 
	//set count
	count = 0;
	//initialize Node pointers to Null
	frontPtr = 0;
	backPtr =0;
}

//***************************************************************
//* Copy Constructor, takes another LinkQueue and creates a new *
//* copy of the LinkQueue.                                      *
//***************************************************************
template<class ItemType>
LinkedQueue<ItemType>::LinkedQueue(const LinkedQueue& aQueue)
{  
	//create pointer to front of LinkQueue that will be copied
	Node<ItemType>* aQueuePtr = aQueue.frontPtr;

	if (aQueuePtr == 0)     //if original list is empty
	{
		frontPtr = backPtr = 0; //initialize pointers to 0
	}
	else //copy each node into list
	{
		//create new node for frontPtr to point too
		frontPtr = new Node<ItemType>();
		//fill front node with Item from aQueue
		frontPtr->setItem(aQueuePtr->getItem());
		//have backPtr point to front of list
		backPtr = frontPtr;
		//move aQueuePtr to next node in queue
		aQueuePtr = aQueuePtr->getNext();

		//loop to copy remaining list
		while (aQueuePtr != 0)
		{
			//variable to hold Items from Nodes of aQueue
			ItemType nextItem = aQueuePtr->getItem();
			//create new node and initialize it with nextItem
			Node<ItemType>* newNodePtr = new Node<ItemType>(nextItem);
			//add new node to list/queue
			backPtr->setNext(newNodePtr);
			//move backPtr to next node or walk to next item
			backPtr = backPtr->getNext();
			//walk aQueuePtr to next item in original list
			aQueuePtr = aQueuePtr->getNext();
		}//end loop

		//set last node/item in queue/list to point to Null
		backPtr->setNext(0);
	}
}  

//***************************************************************
//* Destructor will delete any nodes still in linkedQueue, thus *
//* freeing memory and preventing memory leaks.                 *
//***************************************************************
template<class ItemType>
LinkedQueue<ItemType>::~LinkedQueue()
{
	//Keep removing first node until queue is empty
	while(count != 0)
	{
		dequeue();
	}
}  

//*******************************************************************
//* Function adds a New node to back of Queue, and increments count *
//*******************************************************************
template<class ItemType>
bool LinkedQueue<ItemType>::enqueue(const ItemType& newEntry)
{
	if (count == 0) //Queue is empty
	{
		//create new node and node pointer for newEntry
		Node<ItemType>* nodePtr = new Node<ItemType>(newEntry);
		//Set node's next* to Null
		nodePtr->setNext(0);
		//have frontPtr and backPtr point to new node
		frontPtr = nodePtr;
		backPtr = nodePtr;
	}
	else //Queue is not Empty
	{
		//create new node, storing passed argument into it
		Node<ItemType>* nodePtr = new Node<ItemType>(newEntry);
		//Attach last node in Queue to nodePtr, making it last
		backPtr->setNext(nodePtr);
		//make backPtr point to new end of Queue, nodePtr
		backPtr = nodePtr;
		//set last nodes next* to Null
		nodePtr->setNext(0);
	}
	
	count++;
	return true;
} 

//***************************************************************
//* Removes the first node in List.                             *
//***************************************************************
template<class ItemType>
bool LinkedQueue<ItemType>::dequeue()
{
	if (count == 0)
		return false;
 
	//if only 1 node in queue
	if (count == 1)
	{
		delete frontPtr;   //delete node, resulting in empty queue
		frontPtr = 0;      //set frontPtr to Null
		backPtr = 0;       //set backPtr to Null
	}
	else //queue will not be empty after removing first node in queue
	{
		//create node* that will be used for deletion of first node
		Node<ItemType>* deleteNode = frontPtr;
		//have frontPtr point to next node in queue
		frontPtr = deleteNode->getNext();
		//delete Node
		delete deleteNode;
	}

	count--;
	return true;
} 

#endif
