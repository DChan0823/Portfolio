/****************************************************************
Program Name: FileIO.h
Programmer's Name: Arjan Sohal
****************************************************************/

#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include "PlayerData.h"
#include "HashTable.h"
#include "HashBucket.h"
#include "BinarySearchTree.h"
using namespace std;

typedef PlayerData* PD_PTR;

class FileIO
{
protected:
	BinarySearchTree<PD_PTR>* tree;
	HashTable<PD_PTR>* table;

	int(*compare)(const PD_PTR &left, const PD_PTR &right);
	int(*hashf)(const PD_PTR &obj);
	void(*pDisplay)(PD_PTR &ptrPD);

public:

	FileIO() {}

	FileIO(int(*hashFcn)(const PD_PTR &obj), int(*comp)(const PD_PTR &left, const PD_PTR &right), void displayPD_PTR(PD_PTR &ptrPD)) // BinarySearchTree<PD_PTR>* ptree, HashTable<PD_PTR>* ptable)
	{
		hashf = hashFcn;
		compare = comp;
		pDisplay = displayPD_PTR;
	}

	~FileIO()
	{
	}

	bool readIn();
	bool writeToFileBreadth();
	bool openOutputFile(ofstream &out);
	BinarySearchTree<PD_PTR>* getTreePtr() { return tree; }
	HashTable<PD_PTR>* getTablePtr() { return table; }
};

bool FileIO::readIn()
{
	ifstream inFile;
	string filename;
	int numberOfPlayers;

	cout << "Enter input file pathname: ";
	getline(cin, filename);

	inFile.open(filename.c_str());	

	if (!inFile)
	{
		cout << "File not found 1!\n";
		return false;
	}
	else
	{
		string inString;
		int strCount = 0;

		while (getline(inFile, inString))
		{
			strCount++;
		}

		numberOfPlayers = strCount;

		//cout << numberOfPlayers << endl; //debugging statement

		tree = new BinarySearchTree<PD_PTR>(compare);
		table = new HashBucket<PD_PTR>(hashf, compare, numberOfPlayers*2);

		inFile.close();
	}

	inFile.open(filename.c_str());

	if (!inFile)
	{
		cout << "File not found 2!\n";
		return false;
	}
	else
	{
		string inName, inFaction, inClass, inRace;

		while (inFile >> inName)
		{
			inFile >> inFaction;
			inFile >> inClass;
			inFile >> inRace;

			PlayerData* player = new PlayerData(inName, inFaction, inClass, inRace);

			if (!table->insert(player))
			{
				cout << "Not Inserted into Tree\n\n";
			}
			else
				tree->insert(player);
		}

		inFile.close();
		return true;
	}
}

/*bool FileIO::writeToFileAlph()
{
	ofstream outFile;
	openOutputFile(outFile);

	if (!outFile)
	{
		cout << "File Not Found!\n";
		return false;
	}

	cout << "Writing to File Alphabetically: \n";

	//tree->inOrder(pDisplay);

	outFile.close();
	
	return true;
}*/

bool FileIO::writeToFileBreadth(){

	cin.ignore();
	ofstream outfile;
	openOutputFile(outfile); //opens the specified file (specified in openInputFile())
	if (!outfile){
		cout << "File not found!" << endl; //IF the file is not found, exit the program.
		return false;
	}

	cout << "Writing to File Breadth-First... \n";
	tree->printBreadth(outfile);

	outfile.close(); //closes the file.

	return true;
}

bool FileIO::openOutputFile(ofstream &out)
{
	string filename;
	cout << "Enter output file pathname: ";
	getline(cin, filename);
	cout << endl;
	out.open(filename.c_str());
	return out.is_open();
}