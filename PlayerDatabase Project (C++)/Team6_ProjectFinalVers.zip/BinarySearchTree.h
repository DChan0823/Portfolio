// Binary Search Tree ADT
// Created by Frank M. Carrano and Tim Henry.
// Modified by:

#ifndef _BINARY_SEARCH_TREE
#define _BINARY_SEARCH_TREE

#include <iostream>
#include <fstream>
#include <iomanip>
#include "BinaryNode.h"
#include "BinaryTree.h"
#include "LinkedQueue.h"
using namespace std;

template<class ItemType>
class BinarySearchTree : public BinaryTree<ItemType>
{
private:

	int(*compare)(const ItemType&, const ItemType&);

	// internal insert node: insert newNode in nodePtr subtree
	BinaryNode<ItemType>* _insert(BinaryNode<ItemType>* nodePtr, BinaryNode<ItemType>* newNode);

	// internal remove node: locate and delete target node under nodePtr subtree
	BinaryNode<ItemType>* _remove(BinaryNode<ItemType>* nodePtr, const ItemType target, bool & success);

	// delete target node from tree, called by internal remove node
	BinaryNode<ItemType>* deleteNode(BinaryNode<ItemType>* targetNodePtr);

	// remove the leftmost node in the left subtree of nodePtr
	BinaryNode<ItemType>* removeLeftmostNode(BinaryNode<ItemType>* nodePtr, ItemType & successor);

	// search for target node
	BinaryNode<ItemType>* findNode(BinaryNode<ItemType>* treePtr, const ItemType & target) const;

public:

	BinarySearchTree(int compareNew(const ItemType&, const ItemType&)) { compare = compareNew; }

	BinarySearchTree(const BinarySearchTree<ItemType> & bst)
	{
		compare = bst.compare;

		count = 0;
		
		rootPtr = copyTree(bst.rootPtr);
	}
	// insert a node at the correct location
    bool insert(const ItemType & newEntry);
	// remove a node if found
	bool remove(const ItemType & anEntry);
	// find a target node
	bool getEntry(const ItemType & target, ItemType & returnedItem) const;

	void printIndented();
	void Indent(BinaryNode<ItemType>* nodePtr, int level);
	void printBreadth(ostream &out) const;
};


///////////////////////// public function definitions ///////////////////////////

template<class ItemType>
bool BinarySearchTree<ItemType>::insert(const ItemType & newEntry)
{
	BinaryNode<ItemType>* newNodePtr = new BinaryNode<ItemType>(newEntry);
	rootPtr = _insert(rootPtr, newNodePtr);
	return true;
}

template<class ItemType>
bool BinarySearchTree<ItemType>::remove(const ItemType & target)
{
	bool isSuccessful = false;
	rootPtr = _remove(rootPtr, target, isSuccessful);
	return isSuccessful;
}

template<class ItemType>
bool BinarySearchTree<ItemType>::getEntry(const ItemType& anEntry, ItemType & returnedItem) const
{
	if (findNode(rootPtr, anEntry) == 0)
	{
		return false;
	}
	else
	{
		returnedItem = findNode(rootPtr, anEntry)->getItem();
		return true;
	}
}

template<class ItemType>
void BinarySearchTree<ItemType>::printIndented()
{
	Indent(rootPtr, 0);
}

template<class ItemType>
void BinarySearchTree<ItemType>::Indent(BinaryNode<ItemType>* nodePtr, int level)
{
	if (nodePtr == NULL)
	{
		return;
	}
	else
	{
		level++;
		Indent(nodePtr->getRightPtr(), level);
		cout << setw(level * 3) << "";
		cout << level << ". ";
		(nodePtr->getItem())->write(cout);
		Indent(nodePtr->getLeftPtr(), level);
	}
}

/*template<class ItemType>
void BinarySearchTree<ItemType>::printAlpha() const
{
	inOrder(displayItemType);
}

template<class ItemType>
void BinarySearchTree<ItemType>::writeFileAlpha(ofstream &out) const
{
	inOrder(writeItemType);
}*/

template<class ItemType>
void BinarySearchTree<ItemType>::printBreadth(ostream &out) const
{
	LinkedQueue<BinaryNode<ItemType>*>* queue = new LinkedQueue<BinaryNode<ItemType>*>();

	BinaryNode<ItemType>* visited;
	BinaryNode<ItemType>* leftChild;
	BinaryNode<ItemType>* rightChild;

	queue->enqueue(rootPtr);

	rootPtr->getItem()->write(out);
	
	//rootPtr->setVisited(true);

	while(!queue->isEmpty())
	{
		visited = queue->peekFront();
	
		queue->dequeue();

		leftChild = visited->getLeftPtr();
		rightChild = visited->getRightPtr();
		if (leftChild != 0 ) //&& !leftChild->getVisited())
		{
			leftChild->getItem()->write(out);
			//leftChild->setVisited(true);
			queue->enqueue(leftChild);
		}
		if (rightChild != 0 ) //&& !rightChild->getVisited())
		{
			rightChild->getItem()->write(out);
			//rightChild->setVisited(true);
			queue->enqueue(rightChild);
		}
	}



	delete queue;
}

/*template<class ItemType>
BinarySearchTree<ItemType> & BinarySearchTree<ItemType>::operator=(const BinarySearchTree<ItemType> & sourceTree)
{
	compare = sourceTree.compare; // assign to function pointer
	this->BinaryTree<ItemType>::operator=(sourceTree);
	return *this;
}*/

//////////////////////////// private functions ////////////////////////////////////////////

template<class ItemType>
BinaryNode<ItemType>* BinarySearchTree<ItemType>::_insert(BinaryNode<ItemType>* nodePtr,
                                                          BinaryNode<ItemType>* newNodePtr)
{
	if (nodePtr == 0)
		return newNodePtr;
	if (compare(newNodePtr->getItem(), nodePtr->getItem()) < 0) //*****CHANGE THIS*****
		nodePtr->setLeftPtr(_insert(nodePtr->getLeftPtr(), newNodePtr));
	else
		nodePtr->setRightPtr(_insert(nodePtr->getRightPtr(), newNodePtr));
	return nodePtr; // must return

}

template<class ItemType>
BinaryNode<ItemType>* BinarySearchTree<ItemType>::_remove(BinaryNode<ItemType>* nodePtr,
                                                          const ItemType target, bool & success)

{
	if (nodePtr == 0)
	{
		success = false;
		return 0;
	}
	if (compare(nodePtr->getItem(), target) > 0)
		nodePtr->setLeftPtr(_remove(nodePtr->getLeftPtr(), target, success));
	else if (compare(nodePtr->getItem(), target) < 0)
		nodePtr->setRightPtr(_remove(nodePtr->getRightPtr(), target, success));
	else	// found the node
	{
		nodePtr = deleteNode(nodePtr);
		success = true;
	}
	return nodePtr;
}

template<class ItemType>
BinaryNode<ItemType>* BinarySearchTree<ItemType>::deleteNode(BinaryNode<ItemType>* nodePtr)
{
	if (nodePtr->isLeaf())
	{
		delete nodePtr;
		nodePtr = 0;
		return nodePtr;
	}
	else if (nodePtr->getLeftPtr() == 0)
	{
		BinaryNode<ItemType>* nodeToConnectPtr = nodePtr->getRightPtr();
		delete nodePtr;
		nodePtr = 0;
		return nodeToConnectPtr;
	}
	else if (nodePtr->getRightPtr() == 0)
	{
		BinaryNode<ItemType>* nodeToConnectPtr = nodePtr->getLeftPtr();
		delete nodePtr;
		nodePtr = 0;
		return nodeToConnectPtr;
	}
	else
	{
		ItemType newNodeValue;
		nodePtr->setRightPtr(removeLeftmostNode(nodePtr->getRightPtr(), newNodeValue));
		nodePtr->setItem(newNodeValue);
		return nodePtr;
	}
}

template<class ItemType>
BinaryNode<ItemType>* BinarySearchTree<ItemType>::removeLeftmostNode(BinaryNode<ItemType>* nodePtr,
                                                                     ItemType & successor)
{
	if (nodePtr->getLeftPtr() == 0)
	{
		successor = nodePtr->getItem();
		return deleteNode(nodePtr);
	}
	else
	{
		nodePtr->setLeftPtr(removeLeftmostNode(nodePtr->getLeftPtr(), successor));
		return nodePtr;
	}
}

template<class ItemType>
BinaryNode<ItemType>* BinarySearchTree<ItemType>::findNode(BinaryNode<ItemType>* nodePtr,
                                                           const ItemType & target) const
{
	if (nodePtr == 0)
	{
		return 0;
	}
	else if (compare(nodePtr->getItem(), target) < 0)
	{
		return findNode(nodePtr->getRightPtr(), target);
	}
	else if (compare(nodePtr->getItem(), target) > 0)
	{
		return findNode(nodePtr->getLeftPtr(), target);
	}
	else
	{
		return nodePtr;
	}
}

#endif
