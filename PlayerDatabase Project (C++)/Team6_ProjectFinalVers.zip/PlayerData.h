#pragma once
#include <string>
#include <iomanip>
using namespace std;

class PlayerData
{
private:
	string playerName; //primary key
	string playerRace;
	string playerClass;
	string playerFaction;
public:

	PlayerData(string nm="", string fctn="Alliance", string clss="Warrior", string rc="Human")
	{
		setName(nm); setFaction(fctn); setClass(clss); setRace(rc);
	}
	~PlayerData()
	{
	}

	void setName(string name)
	{ playerName = name; }

	void setRace(string race)
	{ playerRace = race; }

	void setClass(string pclass)
	{ playerClass = pclass; }

	void setFaction(string faction)
	{ playerFaction = faction; }

	string getName()
	{ return playerName; }

	string getRace()
	{ return playerRace; }

	string getClass()
	{ return playerClass; }

	string getFaction()
	{ return playerFaction; }

	//Print player data
	ostream& write(ostream& out)
	{
		out << getName() << " " << getRace() << " " << getClass() << " " << getFaction() << endl << endl;

		return out;
	}
};

