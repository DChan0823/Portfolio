//Author: Matthew Byers
//IDE: Microsoft Visual Studio 2013
//OS: Windows 7 64bit
//Date: 3/15/2015

#ifndef _HASHBUCKET
#define _HASHBUCKET
#include "Bucket.h"
#include <cmath>
#include <iomanip>
using namespace std;

// ---------------------- HashSC Prototype --------------------------
template <class Object>
class HashBucket : public HashTable <Object>// FIX HERE TO BE A DERIVED CLASS OF HashTable
{
	static const int INIT_TABLE_SIZE = 27;
	static const float INIT_MAX_LAMBDA;
private:
	Bucket<Object> * mLists; // for array of buckets
	int mSize;  // number of entries
	int mTableSize; // array size
	float mMaxLambda; // max. load factor
	// ADD HERE: declare static variables
	static int numCollisions;
	static int fullestBucket;

public:
	//Defualt Constructor
	HashBucket();
	// Constructor with out bucketSize
	HashBucket(int (hCCode)(const Object &pcolor), int (comp)(const Object &left, const Object &right), 
		int tableSize = INIT_TABLE_SIZE); // FIX HERE: need add'l parameters
	// Constructor with BucketSize
	HashBucket(int (hCCode)(const Object &pcolor), int (comp)(const Object &left, const Object &right),
		int tableSize, int bucketSize);
	~HashBucket();
	bool contains(const Object & x) const;
	void makeEmpty();
	bool insert(const Object & x);
	bool remove(const Object & x);
	static long nextPrime(long n);
	int size() const { return mSize; }
	bool setMaxLambda(float lm);
	// ADD HERE: declare displayStatistics()
	void displayStatistics() const;
	bool getEntry(const Object & target, Object & returnedItem) const;
	// Displays all hashTable entries in order
	void displayHashTable() const;
	void displayHashTable(ostream &) const;

private:
	void rehash();
	int myHash(const Object & x) const;
};

template <class Object>
const float HashBucket<Object>::INIT_MAX_LAMBDA = .75;

// ADD HERE: initialize static variables
template <class Object>
int HashBucket<Object>::numCollisions = 0;
template <class Object>
int HashBucket<Object>::fullestBucket = 0;

// HashSC method definitions -------------------
template <class Object>// Defualt Constructor
HashBucket<Object>::HashBucket() :mTableSize(INIT_TABLE_SIZE), mSize(0), HashTable(){}

template <class Object>// Constructor with no BucketSize
HashBucket<Object>::HashBucket(int (hCCode)(const Object &pcolor), int (comp)(const Object &left, const Object &right),
	int tableSize) : mSize(0), HashTable(hCCode, comp)
{
	if (tableSize < INIT_TABLE_SIZE)
		mTableSize = INIT_TABLE_SIZE;
	else
		mTableSize = nextPrime(tableSize);

	mLists = new Bucket<Object>[mTableSize];
	mMaxLambda = INIT_MAX_LAMBDA;
}

template <class Object>// Constructor with BucketSize
HashBucket<Object>::HashBucket(int (hCCode)(const Object &pcolor), int (comp)(const Object &left, const Object &right),
	int tableSize, int bucketSize) : mSize(0), HashTable(hCCode, comp)
{
	if (tableSize < INIT_TABLE_SIZE)
		mTableSize = INIT_TABLE_SIZE;
	else
		mTableSize = nextPrime(tableSize);

	mLists = new Bucket<Object>[mTableSize];
	mMaxLambda = INIT_MAX_LAMBDA;
	// loop through bucket array, setting each bucket's size to default
	for (int i = 0; i < mTableSize; i++)
	{
		mLists[i].setSize(bucketSize);
	}
}

template <class Object>
HashBucket<Object>::~HashBucket()
{
	//    for( int i=0; i < mTableSize; ++i )//FIXED******************
	//        delete mLists[i];//FIXED******************
	delete[] mLists;
}

template <class Object>
void HashBucket<Object>::displayStatistics() const
{
	cout << "\n\nIn the Hash Bucket class:\n";
	cout << "Load factor = " << setprecision(6) << fixed << dec << (double)mSize / mTableSize << endl;
	cout << "Number of collisions = " << dec << numCollisions << endl;
	cout << "Largest Bucket = " << dec << fullestBucket << endl << endl;

}

template <class Object>
int HashBucket<Object>::myHash(const Object & x) const
{
	int hashVal;

	hashVal = this->Hash(x) % mTableSize; //may need to do: this->Hash(x)
	if (hashVal < 0)
		hashVal += mTableSize;

	return hashVal;
}

template <class Object>
void HashBucket<Object>::makeEmpty()
{
	int k;

	for (k = 0; k < mTableSize; k++)
		mLists[k].clear();
	mSize = 0;
}

template <class Object>
bool HashBucket<Object>::contains(const Object & x) const
{
	const Bucket<Object> & theList = mLists[myHash(x)];
	Object tempObj;

	if (theList.size() > 0)
	{
		for (int i = 0; i < theList.size(); i++)
		{
			theList.getEntry((i + 1), tempObj);
			if (this->Compare(tempObj, x) == 0)		// CHANGE TO USE this->Compare function         return true;
			{
				return true;
			}

		}
	}

	// not found
	return false;
}

template <class Object>
bool HashBucket<Object>::getEntry(const Object & target, Object & returnedItem) const
{
	// FINISH THIS (should be like remove, but assign to returnedItem if found)
	Bucket<Object> &theList = mLists[myHash(target)];
	Object tempObj;

	for (int i = 0; i < theList.size(); i++)
	{
		theList.getEntry((i + 1), tempObj);
		if (this->Compare(tempObj, target)==0)		// CHANGE TO USE this->Compare function
		{
			returnedItem = tempObj;
			return true;
		}
	}
	// not found
	return false;
}

template <class Object>
bool HashBucket<Object>::remove(const Object & x)
{
	Bucket<Object> &theList = mLists[myHash(x)];
	Object tempObj;

	for (int i = 0; i < theList.size(); i++)
	{
		theList.getEntry((i + 1), tempObj);
		if (this->Compare(tempObj, x) == 0)		// CHANGE TO USE this->Compare function
		{
			theList.remove(i + 1);
			mSize--;
			return true;
		}
	}
	// not found
	cout << "Player: " << x->getName() << " not removed from hash.\n";
	return false;
}

template <class Object>
bool HashBucket<Object>::insert(const Object & x)
{
	Bucket<Object> &theList = mLists[myHash(x)];
	int listSize = theList.size();
	Object tempObj;

	// checks if bucket is full
	if (listSize == theList.getBucketSize())
	{
		cout << "Bucket is Full. Unable to Insert: " << x->getName() << endl << endl;
		return false;
	}
	else
	{
		for (int i = 0; i < listSize; i++)
		{
			theList.getEntry((i + 1), tempObj);
			if (this->Compare(tempObj, x) == 0)
			{
				cout << "Unable to Insert into Hash(Already exists): " << tempObj->getName() << endl;
				return false;
			}
		}
	}
	// ADD HERE: use static variables
	if (theList.size() > 0)
	{
		numCollisions++;
	}
	// not found so we insert at the beginning
	theList.insert(x);
	/*cout << "Inserted into Hash: " << endl;
	x->write(cout);*/
	// ADD HERE: use static variables
	if (fullestBucket < theList.size())
	{
		fullestBucket = theList.size();
	}
	// check load factor
	if (++mSize > mMaxLambda * mTableSize)
		rehash();

	return true;
}

template <class Object>
void HashBucket<Object>::rehash()
{
	Bucket<Object> *oldLists = mLists;
	int k, oldTableSize = mTableSize;
	Bucket<Object> *currList;           // CHANGED********************
	Object tempObj;

	mTableSize = nextPrime(2 * oldTableSize);
	mLists = new Bucket<Object>[mTableSize];

	mSize = 0;
	for (k = 0; k < oldTableSize; k++)
	{
		currList = &oldLists[k];
		for (int i = 0; i < currList->size(); ++i)//updated***************
		{
			currList->getEntry((i + 1), tempObj);//updated***************
			insert(tempObj);
		}

	}
	delete[] oldLists;
}

template <class Object>
bool HashBucket<Object>::setMaxLambda(float lam)
{
	if (lam < .1 || lam > 100)
		return false;
	mMaxLambda = lam;
	return true;
}

template <class Object>
long HashBucket<Object>::nextPrime(long n)
{
	long k, candidate, loopLim;

	// loop doesn't work for 2 or 3
	if (n <= 2)
		return 2;
	else if (n == 3)
		return 3;

	for (candidate = (n % 2 == 0) ? n + 1 : n; true; candidate += 2)
	{
		// all primes > 3 are of the form 6k +/- 1
		loopLim = (long)((sqrt((float)candidate) + 1) / 6);

		// we know it is odd.  check for divisibility by 3
		if (candidate % 3 == 0)
			continue;

		// now we can check for divisibility of 6k +/- 1 up to sqrt
		for (k = 1; k <= loopLim; k++)
		{
			if (candidate % (6 * k - 1) == 0)
				break;
			if (candidate % (6 * k + 1) == 0)
				break;
		}
		if (k > loopLim)
			return candidate;
	}
}

template <class Object>
void HashBucket<Object>::displayHashTable() const
{
	cout << "--------Hash Table Contents-----------\n";
	for (int i = 0; i < mTableSize; i++)
	{
		if (mLists[i].size() > 0)
		{
			Bucket<Object> bList = mLists[i];
			Object tempObj;
			//prints key number
			cout << "Bucket#: " << i << endl;
			for (int b = 0; b < bList.size(); b++)
			{
				bList.getEntry(b + 1, tempObj);
				//cout << "           ";          // provides indent to player print data
				tempObj->write(cout);
			}
		}
	}
}

template <class Object>
void HashBucket<Object>::displayHashTable(ostream &out) const
{
	//out << "--------Hash Table Contents-----------\n";
	for (int i = 0; i < mTableSize; i++)
	{
		if (mLists[i].size() > 0)
		{
			Bucket<Object>* bList = &mLists[i];
			Object tempObj;
			//prints key number
			//out << "Bucket#: " << i << endl;
			for (int b = 0; b < bList->size(); b++)
			{
				bList->getEntry(b + 1, tempObj);
				//cout << "           ";          // provides indent to player print data
				tempObj->write(out);
			}
		}
	}
}

#endif