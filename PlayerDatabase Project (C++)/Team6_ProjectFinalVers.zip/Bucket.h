//Author: Matthew Byers
//IDE: Microsoft Visual Studio 2013
//OS: Windows 7 64bit
//Date: 3/15/2015
#ifndef _BUCKET
#define _BUCKET


template <class ItemType>
class Bucket
{
	static const int DEFAULT_SIZE = 3;
private:
	int bucketSize;
	ItemType *array;
	int itemCount;

public:
	Bucket(){ itemCount = 0; array = 0;  setSize(DEFAULT_SIZE); }
	Bucket(int sz){ array = 0; setSize(sz); }
	~Bucket(){ if (array != 0) delete[] array; }
	void setSize(int sz);
	int getBucketSize() const { return bucketSize; }
	int size() const		{ return itemCount; }
	bool isEmpty() const { return itemCount == 0; }
	void clear(){ itemCount = 0; }

	bool insert(const ItemType& newEntry);
	bool remove(int position);
	bool getEntry(int position, ItemType & anEntry) const;
};

template<class ItemType>
void Bucket<ItemType>::setSize(int sz)
{
	ItemType *tempArray = array;

	array = new ItemType[sz];
	if (tempArray != 0) // changing size from old one?
	{
		int smallerSize = (bucketSize < sz) ? bucketSize : sz;
		for (int i = 0; i < smallerSize; ++i)
			array[i] = tempArray[i];
		delete[] tempArray;
		itemCount = smallerSize;
	}
	else
		itemCount = 0;
	bucketSize = sz;

}

template<class ItemType>
bool Bucket<ItemType>::insert(const ItemType& newEntry)
{
	if (itemCount >= bucketSize) // no more room?
		return false;

	array[itemCount] = newEntry;
	++itemCount;
	return true;
}


template<class ItemType>
bool Bucket<ItemType>::remove(int position)
{
	// check for valid position
	if (position < 1 || position > itemCount)
		return false;

	// remove at index = position-1;
	for (int i = position; i < itemCount; ++i)
		array[i - 1] = array[i];
	itemCount--;
	return true;
}

template<class ItemType>
bool Bucket<ItemType>::getEntry(int position, ItemType & anEntry) const
{
	if (position < 1 || position > itemCount)
		return false;

	anEntry = array[position - 1];
	return true;
}
#endif